;
; GSX test program. Draws various test patterns on a device so you can compare
; how they look when rendered by various drivers.
;
; Version 2.0. Version 1.0 was written in C and based on VTEST, a similar 
; program that I wrote for GEM.
;
; zlib/libpng licence:
; Copyright (c) 2025 John Elliott <seasip.webmaster@gmail.com>
; 
; This software is provided 'as-is', without any express or implied
; warranty. In no event will the authors be held liable for any damages
; arising from the use of this software.
; 
; Permission is granted to anyone to use this software for any purpose,
; including commercial applications, and to alter it and redistribute it
; freely, subject to the following restrictions:
; 
; 1. The origin of this software must not be misrepresented; you must not
;    claim that you wrote the original software. If you use this software
;    in a product, an acknowledgment in the product documentation would be
;    appreciated but is not required.
; 2. Altered source versions must be plainly marked as such, and must not be
;    misrepresented as being the original software.
; 3. This notice may not be removed or altered from any source distribution.
;
; ==================== Equates ============================================
;

;
; CP/M entry point
;
FDOS	equ	5

CR	equ	0Dh	;Special characters
LF	equ	0Ah
EOF	equ	1Ah
;
; BDOS functions
;
CWRITE	equ	2	;Write character to console
LWRITE	equ	5	;Write character to printer
CDIRECT	equ	6	;Direct console read/write
CWSTR	equ	9	;Write string to console
SBDOSVER equ	12	;Get BDOS version
GSXFUNC	equ	73h	;Call to GSX

WHITE	equ	7	; In GSX, colour 7 is white. This differs from GEM
			; where it's colour 1.

	cseg
;
; ==================== Initialisation ======================================
;
; Start by detecting the CPU. If it's an 80x86 print an error message and
; exit.
;
	db	0EBh,04h	;JCE - DOS protection... JMPS LABE
	xchg
	jmp	main
	db	0B4h,09h	;JCE - DOS protection... MOV AH,9
	db	0BAh
	dw      notx80		;DOS protection... MOV DX,OFFSET notx80
	db	0CDh,021h	;DOS protection... INT 21h.
	db	0CDh,020h	;DOS protection... INT 20h.

	db	cr,'GSX test tool v2.0',cr,lf
	db	'Date: 2025-08-30',cr,lf,eof
;
; See if it's an 8080 or a Z80.
;
main:
	sub	a
	jpe	main1
;
; If it's a Z80, then replace the loop-based LDIR with the actual LDIR opcode.
;
	lxi	h,0B0EDh	
	shld	ldir1
	lxi	h,0C9F1h
	shld	ldir1+2
main1:
;
; ==================== Argument parsing ===================================
;
	lhld	6	;Move the stack to the top of memory (in case we're
	mvi	l,0	;still running on the small CCP stack)
	sphl		
	lxi	h,80h	;Command tail
	mov	e,m
	mov	d,h	;DE = command length
	inx	h
	xchg		;DE->command
	dad	d	;HL->end of command
	mvi	m,0
	xchg		;HL->command line
	call	skipsp
	mov	a,m
	call	isdigit
	jc	menu
;
; Parse number
;
	xchg		;DE->command tail
	lxi	h,0	;HL = parsed number
pnum:	ldax	d
	call	isdigit
	jc	pnume	;Got to the end of the number?

	dad	h	;*2
	mov	b,h
	mov	c,l	;BC = HL*2
	dad	h	;*4
	dad	h	;*8
	dad	b	;*10
	sbi	'0'
	mov	c,a
	mvi	b,0
	dad	b	;Add on next digit
	inx	d
	jmp	pnum
;
pnume:	shld	device
;
; ==================== Main Menu ==========================================
;
menu:
	lxi	h,menu
	shld	curmenu	;curmenu = menu to display once an operation is 
			;complete
	call	prcrlf
	call	prcrlf
	lxi	d,devm	;Show which device we are opening
	call	print
	lhld	device
	call	dechl
	call	prcrlf	;List the options
	lxi	d,mainmenu
	call	print
	lda	drawbg	;Show if drawing background is enabled...
	lxi	d,ena
	ora	a
	jnz	menu1
	lxi	d,disa	;... or disabled
menu1:	call	print
	lxi	d,mainm1 ;Print remainder of menu
	call	print
mloop:
	call	getkeyu	;Wait for user to select an option
	cpi	3
	jz	exit
	cpi	1Bh
	jz	exit

	cpi	'A'	;Cell array submenu
	jz	cellamenu
	cpi	'B'	;Toggle whether background is drawn
	jz	togbg	
	cpi	'C'	;Colour submenu
	jz	colrmenu
	cpi	'E'	;Escape submenu
	jz	escmenu
	cpi	'F'	;Fill submenu
	jz	fillmenu
	cpi	'G'	;GDP submenu
	jz	gdpmenu
	cpi	'I'	;Input submenu
	jz	inpmenu
	cpi	'L'	;Line submenu
	jz	linemenu
	cpi	'M'	;Marker submenu
	jz	markmenu
	cpi	'T'	;Text submenu
	jz	textmenu
	cpi	'W'	;Get workstation info
	jz	wsinfo
	cpi	'X'	;Test drawing background
	jz	backgonly
	cpi	'0'		;Hidden option from original GSXTEST program
	jz	option0
	jmp	mloop
;
togbg:	lda	drawbg	;Toggle whether background is drawn
	cma
	sta	drawbg
	jmp	menu
;
; ==================== Line Drawing Tests =================================
;
; The tests tend to be quite repetitive; instead of trying to optimise for
; size, I've often copy-pasted a test and adjusted it slightly.
;
; Most of the line tests have two copies -- one with eight lines 
; emanating from a central point, the other a five-pointed star. The 
; former is intended to exercise a Bresenham-based line drawing algorithm,
; the latter to test any special case for horizontal lines.
;
linemenu:
	lxi	h,linemenu
	shld	curmenu		;Return from tests to LINEMENU
	lxi	d,lines
	call	print		;Show menu
lloop:	call	getkeyu
	cpi	3
	jz	exit		;^C to exit immediately
	cpi	1Bh
	jz	menu		;ESC to return to main menu
	cpi	'1'
	jz	line1		;Other options execute the tests
	cpi	'2'
	jz	line2
	cpi	'3'
	jz	line3
	cpi	'4'
	jz	line4
	cpi	'5'
	jz	line5
	cpi	'6'
	jz	line6
	cpi	'M'
	jz	menu
	jmp	lloop
;
; Line test - pattern 1, combinations of mode and colour
;
line1:
	lhld	device
	call	vopnwk
	call	backg

	mvi	a,1
	call	vslstyle	;Solid line style
	lxi	h,0
	shld	x0
	shld	y0		;Start at 0,0

	mvi	b,8		;Draw in colours 0-7
	lxi	d,1000h
	xra	a
l1col:	call	vslcolor
	inr	a
	lxi	h,0
	shld	x0		;Inner loop (across)
	push	psw
	mvi	c,8
	xra	a
l1row:	ani	3		;Draw in modes 1-4
	inr	a
	call	vswrmode	
	call	vpltest		;Draw test pattern
	lhld	x0
	dad	d		;Move across
	shld	x0
	dcr	c
	jnz	l1row
	pop	psw		;End of row
	lhld	y0
	dad	d		;Move up
	shld	y0
	dcr	b
	jnz	l1col
	
	xra	a		;Reset write mode to default
	call	vswrmode
	jmp	tableau		;Display pattern, wait for keypress
;
; Line test - pattern 2, combinations of mode and colour
;
line2:
	lhld	device
	call	vopnwk
	call	backg

	mvi	a,1
	call	vslstyle
	lxi	h,0
	shld	x0
	shld	y0

	mvi	b,8
	lxi	d,1000h
	xra	a
l2col:	call	vslcolor
	inr	a
	lxi	h,0
	shld	x0
	push	psw
	mvi	c,8
	xra	a
l2row:	ani	3
	inr	a
	call	vswrmode	
	call	vstar
	lhld	x0
	dad	d
	shld	x0
	dcr	c
	jnz	l2row
	pop	psw
	lhld	y0
	dad	d
	shld	y0
	dcr	b
	jnz	l2col
	
	xra	a
	call	vswrmode
	jmp	tableau
;
; Line test - pattern 1, combinations of mode and style
;
line3:
	lhld	device
	call	vopnwk
	call	backg

	lxi	h,0
	shld	x0
	shld	y0

	mvi	b,8
	lxi	d,1000h
	xra	a
l3col:	inr	a
	call	vslstyle
	lxi	h,0
	shld	x0
	push	psw
	mvi	c,8
	xra	a
l3row:	ani	3
	inr	a
	call	vswrmode	
	call	vpltest
	lhld	x0
	dad	d
	shld	x0
	dcr	c
	jnz	l3row
	pop	psw
	lhld	y0
	dad	d
	shld	y0
	dcr	b
	jnz	l3col
	
	xra	a
	call	vswrmode
	jmp	tableau
;
; Line test - pattern 2, combinations of mode and style
;
line4:
	lhld	device
	call	vopnwk
	call	backg

	lxi	h,0
	shld	x0
	shld	y0

	mvi	b,8
	lxi	d,1000h
	xra	a
l4col:	inr	a
	call	vslstyle
	lxi	h,0
	shld	x0
	push	psw
	mvi	c,8
	xra	a
l4row:	ani	3
	inr	a
	call	vswrmode	
	call	vstar
	lhld	x0
	dad	d
	shld	x0
	dcr	c
	jnz	l4row
	pop	psw
	lhld	y0
	dad	d
	shld	y0
	dcr	b
	jnz	l4col
	
	xra	a
	call	vswrmode
	jmp	tableau
;
; Line test - pattern 1, combinations of mode and width
;
line5:
	lhld	device
	call	vopnwk
	call	backg

	mvi	a,3	 ;Choose a dashed line style. It probably won't
	call	vslstyle ;have an effect, but in case it does we get to see it 

	lxi	h,0
	shld	x0
	shld	y0
;
; Attempt to work out a plausible range of line widths to test with.
;
	lhld	lwidths	;BC = line widths
	mov	b,h
	mov	c,l	;BC = count of widths
	lhld	maxlw	;Max line width
	xchg		;DE = max line width
	lhld	minlw	;HL = min line width
	push	h
	call	calcsteps
	pop	d	;DE = line width, HL = increment
	mvi	b,8
l5col:	push	h
	push	d
	xchg
	call	vslwidth
	lxi	h,0
	shld	x0
	mvi	c,8
	xra	a
l5row:	ani	3
	inr	a
	call	vswrmode	
	call	vpltest
	lhld	x0
	lxi	d,1000h
	dad	d
	shld	x0
	dcr	c
	jnz	l5row
	lhld	y0
	dad	d
	shld	y0
	pop	d
	pop	h
	xchg
	dad	d	;Add increment to width
	xchg
	dcr	b
	jnz	l5col
	
	xra	a
	call	vswrmode
	jmp	tableau
;
; Line test - pattern 2, combinations of mode and width
;
line6:
	lhld	device
	call	vopnwk
	call	backg

	mvi	a,3
	call	vslstyle

	lxi	h,0
	shld	x0
	shld	y0

	lhld	lwidths	;BC = line widths
	mov	b,h
	mov	c,l
	lhld	maxlw	;Max line width
	xchg		;DE = max line width
	lhld	minlw	;HL = min line width
	push	h
	call	calcsteps
	pop	d	;DE = line width, HL = increment
	mvi	b,8
l6col:	push	h
	push	d
	xchg
	call	vslwidth
	lxi	h,0
	shld	x0
	mvi	c,8
	xra	a
l6row:	ani	3
	inr	a
	call	vswrmode	
	call	vstar
	lhld	x0
	lxi	d,1000h
	dad	d
	shld	x0
	dcr	c
	jnz	l6row
	lhld	y0
	dad	d
	shld	y0
	pop	d
	pop	h
	xchg
	dad	d	;Add increment to width
	xchg
	dcr	b
	jnz	l6col
	
	xra	a
	call	vswrmode
	jmp	tableau
;
; Work out the increment to apply to the line size when testing widths.
; 
; Enter with BC = number of sizes, DE = max size, HL = min size
;
calcsteps:
	ana	a
	mov	a,e	;Let HL = DE - HL, ie max - min
	sbb	l	
	mov	l,a
	mov	a,d
	sbb	h
	mov	h,a	;HL = max - min
	xchg		;DE = max - min
	lxi	h,0	;HL = result
cs1:	mov	a,b
	ora	a
	jnz	cs2
	mov	a,c
	cpi	2
	rc		;If there is only one size return HL=0
cs2:
	ana	a
	mov	a,e	;Divide DE (size range) by BC (count of sizes)
	sbb	c	;using repeated subtractions. HL will be quotient
	mov	e,a
	mov	a,d
	sbb	b
	mov	d,a	
	rc		;If that caused a carry return HL
	inx	h
	jmp	cs2	
;
;
; Draw first polyline test pattern at x0,y0
;
vpltest:
	push	h
	push	d
	push	b
	push	psw

	mvi	b,8	;Draw 8 lines
	lxi	h,lp0	;First line
vplt1:	push	b
	push	h
	lxi	d,ptsin	;Send translated coords to ptsin
vplt2:	call	copypt
	call	copypt
	lxi	h,2
	shld	nptsin
	lxi	h,6	;v_pline
	call	gsxcall	
	pop	h
	lxi	d,8
	dad	d
	pop	b
	dcr	b
	jnz	vplt1
	
	pop	psw
	pop	b
	pop	d
	pop	h
	ret
;
;
; Draw second polyline test pattern at x0,y0
;
vstar:
	push	h
	push	d
	push	b
	push	psw

	lxi	h,star
	lxi	d,ptsin	;Send translated coords to ptsin
	mvi	b,6
vstar1:	call	copypt
	dcr	b
	jnz	vstar1
	lxi	h,6
	shld	nptsin
	lxi	h,6	;v_pline
	call	gsxcall	
	
	pop	psw
	pop	b
	pop	d
	pop	h
	ret
;
	dseg
x0:	dw	0	;Current X position
y0:	dw	0	;Current Y position
	cseg
;
; ==================== Polymarker Tests ==================================
;
; The polymarker API is much like the polyline. We will draw a pattern of 
; four markers in a diamond shape.
;
; To work around a bug in DDFXHR8 / DDFXLR8, the polymarker test screens 
; draw a piece of dummy text before doing any polymarker output. 
;
markmenu:
	lxi	h,markmenu	;After tests return to MARKMENU
	shld	curmenu
	lxi	d,markers	;Show the menu
	call	print
mkloop:	call	getkeyu
	cpi	3
	jz	exit
	cpi	1Bh		;Usual options
	jz	menu
	cpi	'1'
	jz	mark1
	cpi	'2'
	jz	mark2	
	cpi	'3'
	jz	mark3
	cpi	'4'
	jz	mark4
	cpi	'M'
	jz	menu
	jmp	mkloop
;
; First test: Mode and style.
;
mark1:	lhld	device	;Set up the same way as for a polyline
	call	vopnwk
	call	backg
	call	mdtext	;But with the extra call to draw text

	mvi	a,1
	call	vsmcolor
	lxi	h,0
	shld	x0
	shld	y0

	mvi	b,8	;Loop over styles (vertical)
	lxi	d,1000h
	xra	a
mk1col:	inr	a
	call	vsmtype
	lxi	h,0
	shld	x0
	push	psw
	mvi	c,8	; Loop over modes (horizontal)
	xra	a
mk1row:	ani	3
	inr	a
	call	vswrmode	
	call	vmktest
	lhld	x0
	dad	d
	shld	x0
	dcr	c
	jnz	mk1row
	pop	psw
	lhld	y0
	dad	d
	shld	y0
	dcr	b
	jnz	mk1col
	jmp	tableau
;
; Draw a dummy piece of text on screen.
;
mdtext:	
	xra	a
	call	vswrmode
	mvi	a,WHITE
	call	vstcolor

	lhld	minchy		;Get min character height
	call	vstheight	;Select that (to get character dimensions)
	lhld	csize+2
	lxi	d,7C00h
	call	subdehl		;Draw the text at top - 400h - char height
	shld	ptsin+2
	lxi	h,2000h		;X position is fixed
	shld	ptsin
	lxi	h,dummymsg
	call	vatext		;Draw the text
	ret
;
	dseg
dummymsg:
	db	'Dummy text message',0
	cseg

;
; Second marker test resembles the first except the inner loop is over colour,
; not style.
;
mark2:	lhld	device
	call	vopnwk
	call	backg
	call	mdtext

	mvi	a,3
	call	vsmtype
	lxi	h,0
	shld	x0
	shld	y0

	mvi	b,8
	lxi	d,1000h
	xra	a
mk2col:	call	vsmcolor
	lxi	h,0
	shld	x0
	inr	a
	push	psw
	mvi	c,8
	xra	a
mk2row:	ani	3
	inr	a
	call	vswrmode	
	call	vmktest
	lhld	x0
	dad	d
	shld	x0
	dcr	c
	jnz	mk2row
	pop	psw
	lhld	y0
	dad	d
	shld	y0
	dcr	b
	jnz	mk2col
	
	xra	a
	call	vswrmode
	jmp	tableau
;
; Third marker test resembles the first except the inner loop is over height,
; not style.
;
mark3:	lhld	device
	call	vopnwk
	call	backg
	call	mdtext
	mvi	a,1
	call	vsmcolor

	mvi	a,3
	call	vsmtype
	lxi	h,0
	shld	x0
	shld	y0

	lhld	msizes	;BC = number of sizes
	mov	b,h
	mov	c,l
	lhld	maxmh	;Max marker height
	xchg		;DE = max marker height
	lhld	minmh	;HL = min marker height
	push	h
	call	calcsteps
	pop	d	;DE = initial height, HL = increment
	mvi	b,8
mk3col:
	push	h
	push	d
	xchg
	call	vsmheight
	lxi	h,0
	shld	x0
	mvi	c,8
	xra	a
mk3row:	ani	3
	inr	a
	call	vswrmode	
	call	vmktest
	lhld	x0
	lxi	d,1000h
	dad	d
	shld	x0
	dcr	c
	jnz	mk3row
	lhld	y0
	dad	d
	shld	y0
	pop	d
	pop	h
	xchg
	dad	d	;Add increment to width
	xchg
	dcr	b
	jnz	mk3col
	xra	a
	call	vswrmode
	jmp	tableau
;
; And the fourth marker test checks combinations of style and height.
;
mark4:	lhld	device
	call	vopnwk
	call	backg
	call	mdtext
	mvi	a,1
	call	vsmcolor

	mvi	a,3
	call	vswrmode
	lxi	h,0
	shld	x0
	shld	y0

	lhld	msizes	;BC = number of sizes
	mov	b,h
	mov	c,l
	lhld	maxmh	;Max marker height
	xchg		;DE = max marker height
	lhld	minlw	;HL = min marker height
	push	h
	call	calcsteps
	pop	d	;DE = initial height, HL = increment
	mvi	b,8
mk4col:
	push	h
	push	d
	xchg
	call	vsmheight
	lxi	h,0
	shld	x0
	mvi	c,8
	xra	a
mk4row:	call	vsmtype	
	inr	a
	call	vmktest
	lhld	x0
	lxi	d,1000h
	dad	d
	shld	x0
	dcr	c
	jnz	mk4row
	lhld	y0
	dad	d
	shld	y0
	pop	d
	pop	h
	xchg
	dad	d	;Add increment to width
	xchg
	dcr	b
	jnz	mk4col
	xra	a
	call	vswrmode
	jmp	tableau
;
; The common routine to draw the polymarker test pattern at x0,y0
;
vmktest:
	push	h
	push	d
	push	b
	push	psw

	lxi	h,diamond
	lxi	d,ptsin	;Send translated coords to ptsin
	mvi	b,4
vmkt1:	call	copypt
	dcr	b
	jnz	vmkt1
	lxi	h,4
	shld	nptsin
	lxi	h,7	;v_pmarker
	call	gsxcall	
	
	pop	psw
	pop	b
	pop	d
	pop	h
	ret
;
; ==================== Escape Tests =======================================
;
; In GSX, the 'escape' function is mainly used for text screen control and 
; manual drawing / undrawing of the mouse pointer. There are five tests 
; overall.
;
escmenu:
	lxi	h,escmenu
	shld	curmenu
	lxi	d,escs
	call	print
eloop:	call	getkeyu
	cpi	3
	jz	exit
	cpi	1Bh
	jz	menu
	cpi	'M'
	jz	menu
	cpi	'1'
	jz	esc1
	cpi	'2'
	jz	esc2
	cpi	'3'
	jz	esc3
	cpi	'4'
	jz	esc4
	cpi	'5'
	jz	esc5
	jmp	eloop
;
; First escape test is to get the size of the text screen.
;
esc1:	lhld	device
	call	vopnwk		;Open the device (but don't draw the background)
	lxi	h,0
	shld	nintot
	lxi	h,1		;Query text screen size
	call	vescape
	lhld	intout
	push	h		;And save it on the stack, so that if intout
	lhld	intout+2	;is overwritten by subsequent operations it
	push	h		;doesn't matter
	lhld	nintot		;Also save the count of intin
	push	h
	call	vclswk		;Close the display
	pop	h		;Restore nintot
	mov	a,h		;Number of integers supposedly returned
	ora	l
	lxi	d,tsnone
	cz	print		;If it was none, show a warning (probable
	lxi	d,tsdim		;driver bug; this function should always be 
	call	print		;be implemented and return 2 ints)
	pop	h
	call	dechl		;Show the value that was returned, even if
	mvi	e,'x'		;it's gibberish
	call	echar
	pop	h
	call	dechl
esc1b:	call	prcrlf
	call	prcrlf
	jmp	escmenu
;
; This test checks the escape codes used by GSX to control the text screen
;
esc2:	lhld	device
	call	vopnwk
;
; Start by doing the same thing as option 1: Get text screen size. If that 
; fails there is no text screen.
;
	lxi	h,1
	call	vescape	;Get text mode dimensions
	lhld	intout
	shld	txtrows
	mov	a,h
	ana	l	
	inr	a
	jz	esc2z
	lhld	intout+2
	shld	txtcols
	mov	a,h
	ana	l	
	inr	a
	jz	esc2z
;
; Text screen appears to be present. Switch to it.
;
	lxi	h,3
	call	vescape	;Enter text mode
;
; Now draw a text version of the test screen: Four quadrants with different 
; colours, some normal and some inverse.
;
e2redr:	call	esc2bg	;Draw the background. Returns DE = cursor pos
;
; Interactive test with its own keys:
;
e2loop:	call	getkeyu
	cpi	'H'	;H J K L (as in vim) move the cursor around
	jz	e2left
	cpi	'L'
	jz	e2right
	cpi	'J'
	jz	e2down
	cpi	'K'
	jz	e2up
	cpi	'X'	;X redraws the test pattern
	jz	e2redr
	cpi	'C'
	jz	e2cleos
	cpi	'D'	;C / D clear to end of screen / end of line
	jz	e2cleol
	cpi	'A'	;A homes the cursor
	jz	e2home
	cpi	'G'	;G gets cursor position
	jz	e2gpos

	cpi	1Bh	;ESC / M ends test
	jz	esc2y
	cpi	'M'
	jz	esc2y
	jmp	e2loop
;
; Most of these are simple calls to an escape function 
;
e2up:	call	curup
	jmp	e2loop
;
e2left:	call	curleft
	jmp	e2loop
;
e2right:
	call	curright
	jmp	e2loop
;
e2down:	call	curdown
	jmp	e2loop
;
e2home:	call	thome
	jmp	e2loop

e2cleos:
	call	tcleos
	jmp	e2loop
;
e2cleol:
	call	tcleol
	jmp	e2loop
;
; End of test: Switch back to graphics mode, close workstation, finish
;
esc2y:	lxi	h,2
	call	vescape
	call	vclswk	
	jmp	escmenu
;
; Report failure to get cursor position
;
esc2z:	call	vclswk
	lxi	d,tsfail
	call	print
	jmp	escmenu	
;
; Draw the text screen with some messages at various positions
;
esc2bg:	call	textbg
	lxi	d,2
	call	setcurpos
	lxi	d,esc2m1
	call	esctext
	lxi	d,0202h
	call	setcurpos
	lxi	d,esc2m2
	call	esctext
	lxi	d,0402h
	call	setcurpos
	lxi	d,esc2m3
	call	esctext
;
; Put the cursor in the middle of the screen (and return its position in DE)
;
	lda	txtrows
	ana	a
	rar
	mov	d,a
	lda	txtcols
	ana	a
	rar
	mov	e,a	
	jmp	setcurpos
;
; Get the current cursor position, and display it
;
e2gpos:	lxi	h,15	;Get the position
	call	vescape
	lhld	intout
	lxi	d,80h	;Render it to a string at 80h
	call	mdechl
	mvi	a,','
	stax	d
	inx	d
	lhld	intout+2
	call	mdechl
	mvi	a, ' '	;Follow the string with 6 spaces (so that it overwrites
	mvi	b,6	;any previous string)
e2ga:	stax	d
	inx	d
	dcr	b
	jnz	e2ga
	xra	a
	stax	d

	lda	intout	;Stash the returned cursor position into DE
	dcr	a	;(converting to 0-based)
	mov	d,a
	lda	intout+2
	dcr	a
	mov	e,a
	push	d	;And push DE onto the stack

	lxi	d,0810h
	call	setcurpos	;Display the returned value at row=8 col=16
	lxi	d,80h
	call	esctext

	pop	d	;Then restore DE and put the cursor back where it was
	call	setcurpos
	jmp	e2loop
;
; Escape test 3 inquires if there is a mouse / tablet present
;
esc3:	lhld	device
	call	vopnwk
	lxi	h,16
	call	vescape
	lhld	intout
	push	h		;Mouse / tablet status
	lhld	nintot
	push	h
	call	vclswk
	pop	h
	mov	a,h		;Number of integers supposedly returned
	ora	l
	lxi	d,tsnone
	cz	print		;If it was none, show a warning (probable
	lxi	d,tabres	;driver bug; this function should always be 
	call	print		;be implemented)
	pop	h
	call	dechl	
	call	prcrlf
	call	prcrlf
	jmp	escmenu
;
; Escape test 4: Hard copy. Draw a pattern then trigger the hard copy.
;
esc4:	lhld	device
	call	vopnwk
	call	backg
	call	fill5body	;Draw the test pattern from fill test 5
	call	text5body	;Superimpose the text from text test 5
	lxi	h,17
	call	vescape		;Do the hard copy
	call	vclswk
	jmp	escmenu		;And immediately shut down, rather than wait
				;for a keypress
;
; Test 5: Graphics cursor positioning.
;
esc5:	lhld	device
	call	vopnwk
	call	backg
	call	fill5body	;Draw the test pattern from fill test 5
	mvi	a,WHITE
	call	vstcolor	;Superimpose a caption hinting what keys 
	lxi	h,0		;do what
	shld	ptsin
	shld	ptsin+2
	lxi	h,curmsg
	call	vatext
	call	text5body	;Superimpose the text from text test 5
esc5a:	lxi	h,4000h
	shld	gcurx
	shld	gcury		;Start the cursor off in the middle of the
	mov	d,h		;screen
	mov	e,l		
	call	vshowc		;And draw it 
esc5lp:
	call	getkeyu	
	cpi	'H'
	jz	esc5b		;Cursor left
	cpi	'J'
	jz	esc5h		;Cursor down
	cpi	'K'
	jz	esc5f		;Cursor up
	cpi	'L'
	jz	esc5d		;Cursor right
	cpi	'M'
	jz	esc5z
	cpi	1Bh
	jz	esc5z	
	jmp	esc5lp
;
esc5b:	lhld	gcurx		;Cursor left
	lxi	d,-128
	dad	d
	mov	a,h
	ani	80h
	jz	esc5c
	lxi	h,0
esc5c:	shld	gcurx
	jmp	esc5y
;
esc5d:	lhld	gcurx		;Cursor right
	lxi	d,128
	dad	d
	mov	a,h
	ani	80h
	jz	esc5e
	lxi	h,7FFFh
esc5e:	shld	gcurx
	jmp	esc5y
;
esc5f:	lhld	gcury	;Cursor up
	lxi	d,128
	dad	d
	mov	a,h
	ani	80h
	jz	esc5g
	lxi	h,7FFFh
esc5g:	shld	gcury
	jmp	esc5y
;
esc5h:	lhld	gcury	;Cursor down
	lxi	d,-128
	dad	d
	mov	a,h
	ani	80h
	jz	esc5i
	lxi	h,0
esc5i:	shld	gcury
	jmp	esc5y
;
; Cursor has moved. Undraw it and redraw it.
;
esc5y:	lxi	h,19	;Undraw the pointer
	call	vescape
	lhld	gcury	;And redraw it in the new location
	xchg
	lhld	gcurx
	call	vshowc
	jmp	esc5lp

esc5z:	call	vclswk
	jmp	escmenu

	dseg
gcurx:	dw	0
gcury:	dw	0
curmsg:	db	'H/J/K/L to move cursor; M or ESC to finish',0
	cseg

;
; Draw a text mode approximation of the usual 4-quadrant background
;
textbg:
	lhld	txtrows	;Number of rows
	call	rrhl	;Half number of rows
	mov	b,h
	mov	c,l
	lxi	d,0
tbg1:	lxi	h,20AAh	;Fill with spaces and asterisks
	call	txtfill
	inr	d
	dcx	b	
	mov	a,b
	ora	c
	jnz	tbg1
;
; Now work out the number of rows left: (screen height - (screen height / 2))
;
	push	d
	lhld	txtrows		;HL = text rows
	mov	d,h
	mov	e,l		;DE = text rows
	call	rrhl		;HL = text rows / 2
	call	subdehl
	pop	d

	mov	b,h
	mov	c,l
tbg2:	lxi	h,0A32Dh	;Fill with hashes and dashes
	call	txtfill
	inr	d
	dcx	b
	mov	a,b
	ora	c
	jnz	tbg2
	ret	
;
; For debugging: output HL while preserving registers
;
;;showhl:
;;	push	h
;;	push	d
;;	push	b
;;	push	psw
;;	call	dechl
;;	call	dspace
;;	pop	psw
;;	pop	b
;;	pop	d
;;	pop	h
;;	ret

;
; Fill a row of the screen with a pattern. D=row HL=pattern. Within the 
; pattern, bits 0-6 give character, bit 7 is set for reverse video
;
txtfill:
	push	d	;D = row
	push	b
	push	h	;HL = text pattern
	call	setcurpos

	lda	txtcols
	mov	l,a
	ana	a
	rar		;A = screen width / 2
	mov	b,a	;B = columns for pattern 1
	mov	a,l
	sub	b
	mov	c,a	;C = columns for pattern 2

	pop	d	;D = pattern, B = count
	push	d
	call	txtstr
	mov	d,e
	mov	b,c	;D = pattern, B = count	
	dcr	b	;Don't fill right to the edge in case of wrapping
	call	txtstr
stop:	call	revoff
	pop	h
	pop	b
	pop	d
	ret
;
; Output a string of B copies of character D. Bit 7 of D set for reverse 
; video.
;
txtstr:	
	push	b
	push	d
	push	h

	mov	a,d		;High bit of pattern gives normal / reverse
	ani	80h		;video setting
	cnz	revon	
	cz	revoff	

	mov	l,b
	mvi	h,0
	shld	nintin
	lxi	h,intin		;Build the string directly in INTIN
	mov	a,d
	ani	7Fh
txtstr1:
	mov	m,a
	inx	h
	mvi	m,0
	inx	h
	dcr	b
	jnz	txtstr1
	lxi	h,0		;No points
	shld	nptsin
	lxi	h,12		;Escape 12 (output text)
	shld	contrx
	lxi	h,5
	call	gsxcall
tstop:	pop	h
	pop	d
	pop	b	
	ret	
;
	dseg
txtrows: dw	0
txtcols: dw	0
tsdim:	db	'Text screen dimensions: $'
tabres:	db	'Pointing device present: $'
tsnone:	db	'[GSX claims 0 values returned]',cr,lf,'$'
tsfail:	db	'Text mode not supported.',cr,lf,lf,'$'
esc2m1:	db	'Row=0 Col=2. H/J/K/L move cursor. X redraws background',0
esc2m2:	db	'Row=2 Col=2. C clears to end of screen, D to end of line',0
esc2m3: db	'Row=4 Col=2. A homes cursor. G gets cursor pos. M/ESC ends',0
	cseg

;
; ==================== Cell Array Tests ===================================
;
; Cell arrays seem to be one of the areas of GSX that almost no driver 
; implements, except maybe as a fallback to a rectangular outline. So with
; these tests I'm less sure than with some of the others whether they're
; a good way to check the functionality. 
;
cellamenu:
	lxi	h,cellamenu
	shld	curmenu
	lxi	d,cellas	;Display the menu
	call	print
aloop:	call	getkeyu
	cpi	3
	jz	exit
	cpi	1Bh
	jz	menu
	cpi	'M'
	jz	menu
	cpi	'1'		;Choice of three tests
	jz	array1
	cpi	'2'
	jz	array2
	cpi	'3'
	jz	array3
	jmp	aloop
;
array1:	lhld	device		;Test 1: Draw cell array
	call	vopnwk
	call	backg

	lxi	h,1		;Write mode. I don't know why the cell 
	shld	contrx+6	;array takes the mode as a parameter 
	lxi	h,0		;when everything else uses the value set by
	shld	x0		;function 32, but there you go.
	shld	y0

	mvi	b,8		;Usual setup of drawing 8 x 8 grid of test
	lxi	d,1000h		;patterns.
arr1a:	inr	a
	lxi	h,0
	shld	x0
	push	psw
	mvi	c,8
	xra	a
arr1b:	ani	3
	inr	a
	sta	contrx+6	;Setting a different write mode each time
	call	arrtest
	lhld	x0
	dad	d
	shld	x0
	dcr	c
	jnz	arr1b
	pop	psw
	lhld	y0
	dad	d
	shld	y0
	dcr	b
	jnz	arr1a
	jmp	tableau
;
; Array tests 2 and 3 are variations on the same basic functionality 
; (write a cell array and then read it back) and they are implemented
; using the same code. atest holds 2 or 3 to say which test is being 
; performed.
;
array2:	mvi	a,2
	sta	atest
	jmp	a2begin
;
array3:	mvi	a,3
	sta	atest
a2begin:
	lhld	device
	call	vopnwk
	call	backg

	mvi	a,1
	call	vswrmode
	mvi	a,WHITE
	call	vstcolor

	lxi	h,1		;Draw the test pattern
	shld	contrx+6
	lxi	h,0
	shld	x0
	shld	y0
	call	arrtest
;
; Now read the test pattern back (into intout). Firstly blank intout to -1
; (so all cells initialise to 'could not read').
;
	lxi	h,intout
	lxi	d,intout+1
	lxi	b,511
	mvi	m,0FFh
	call	doldir

	lda	atest	;If option 3 is selected, reprogram the palette
	cpi	3	;between draw and read operations. That's the 
	cz	pal3270 ;only difference between options 2 and 3.

	lxi	h,2
	shld	nptsin
	lxi	h,256
	shld	nintin
;
; PTSIN should already contain the coordinates used when the array was drawn
;
	lxi	h,16	;Read a 16x16 array
	shld	contrx
	shld	contrx+2	
	lxi	h,27
	call	gsxcall	;into INTOUT
;
; Display the array as text in the top LH corner of the screen
;
	lxi	h,0
	shld	x0
	lxi	h,7C00h
	shld	y0
	lxi	h,intout
	mvi	b,16
a2a:	mvi	c,16
a2b:	mov	e,m	;Get next array entry
	inx	h
	mov	d,m
	inx	h
	push	b
	push	h	
	lhld	x0	;Set plot position to output it
	shld	ptsin
	lhld	y0
	shld	ptsin+2

	mov	a,d	;If it is 0FFFFh (-1) then display "-1".
	ana	e
	inr	a	;Otherwise display it as normal
	jnz	a2c
	lxi	h,mns1	;"-1"
	jmp	a2d

a2c:	xchg		;HL = number to write
	lxi	d,80h
	push	d
	call	mdechl	;Expand it to a text string at 80h
	xra	a
	stax	d	
	pop	h
a2d:	call	vatext	;And display that text

	lhld	x0
	lxi	d,400h	;Move right for next cell
	dad	d
	shld	x0

	pop	h
	pop	b
	dcr	c	;End of row
	jnz	a2b
	push	h
	lxi	h,0	;Move down for next row
	shld	x0
	lhld	y0
	lxi	d,0FC00h
	dad	d
	shld	y0

	pop	h
	dcr	b
	jnz	a2a
;
; Array dumped. Now use Write Cell Array to draw what we just read in
;
	lxi	h,1	;Write mode
	shld	contrx+6
	lxi	h,2000h
	shld	x0
	shld	y0
	call	arepaint
	
	jmp	tableau
;
; arepaint draws the 16x16 cell array in intout.
;
arepaint:
	push	psw
	push	b
	push	d	
	push	h
	lxi	h,intout
	jmp	arrt1	
;
; arrtest draws a 16x16 array using a suitable test pattern
;
arrtest:	
	push	psw
	push	b
	push	d	
	push	h
	lxi	h,tcell		;Use tcell for displays with >= 5 colours
	lda	dcolrs		;visible at once	
	ora	a
	jz	arrt1
	cpi	5
	jnc	arrt1
	lxi	h,mcell		;For displays with <= 4 colours, use mcell

arrt1:	shld	pintin
	lxi	h,2		;Set up the coordinates
	shld	nptsin
	lhld	x0
	lxi	b,0100h
	lxi	d,0E00h
	dad	b
	shld	ptsin		;Lower left corner
	dad	d
	shld	ptsin+4		;Upper right corner
	lhld	y0
	dad	b
	shld	ptsin+2		;Lower left corner
	dad	d
	shld	ptsin+6		;Upper right corner

	lxi	h,256		;Set up the bitmap
	shld	nintin
	lxi	h,16
	shld	contrx
	shld	contrx+2
	shld	contrx+4
	lxi	h,10		;Draw cell array
	call	gsxcall
	lxi	h,intin
	shld	pintin
	pop	h
	pop	d
	pop	b
	pop	psw
	ret

	dseg
atest:	db	0	;To distinguish between array tests 2 & 3
mns1:	db	'-1',0	;To display 0xFFFF as -1
;
; Bitmap for displays with 5+ colours
;
tcell:	dw	0,0,5,0,5,0,5,0,0,5,0,5,0,5,0,0
	dw	0,0,0,5,0,7,7,7,7,7,7,0,5,0,0,0
	dw	0,0,0,0,7,6,6,6,6,6,6,7,0,0,0,0
	dw	0,0,0,7,6,6,6,6,6,6,6,6,7,0,0,0
	dw	0,0,7,6,6,7,7,6,6,7,7,6,6,7,0,0
	dw	0,0,7,6,7,2,2,7,7,4,4,7,6,7,0,0
	dw	0,7,6,6,7,2,3,7,7,4,3,7,6,6,7,0
	dw	0,7,6,6,6,7,7,6,6,7,7,6,6,6,7,0
	dw	0,7,6,6,6,6,6,6,6,6,6,6,6,6,7,0
	dw	0,7,6,6,6,6,6,6,6,6,6,6,6,6,7,0
	dw	0,0,7,6,1,1,6,6,6,6,1,1,6,7,0,0
	dw	0,0,7,6,6,1,1,1,1,1,1,6,6,7,0,0
	dw	0,0,0,7,6,6,6,6,6,6,6,6,7,0,0,0
	dw	0,0,0,0,7,6,6,6,6,6,6,7,0,0,0,0
	dw	0,0,0,0,0,7,7,7,7,7,7,0,0,0,0,0
	dw	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
;
; Bitmap for displays with <= 4 colours. The main difference is that the
; interior of the bitmap uses colour 0 rather than colour 6.
;
mcell:	dw	0,0,5,0,5,0,5,0,0,5,0,5,0,5,0,0
	dw	0,0,0,5,0,7,7,7,7,7,7,0,5,0,0,0
	dw	0,0,0,0,7,0,0,0,0,0,0,7,0,0,0,0
	dw	0,0,0,7,0,0,0,0,0,0,0,0,7,0,0,0
	dw	0,0,7,0,0,2,2,0,0,2,2,0,0,7,0,0
	dw	0,0,7,0,2,0,0,2,2,0,0,2,0,7,0,0
	dw	0,7,0,0,2,0,3,2,2,0,3,2,0,0,7,0
	dw	0,7,0,0,0,2,2,0,0,2,2,0,0,0,7,0
	dw	0,7,0,0,0,0,0,0,0,0,0,0,0,0,7,0
	dw	0,7,0,0,0,0,0,0,0,0,0,0,0,0,7,0
	dw	0,0,7,0,1,1,0,0,0,0,1,1,0,7,0,0
	dw	0,0,7,0,0,1,1,1,1,1,1,0,0,7,0,0
	dw	0,0,0,7,0,0,0,0,0,0,0,0,7,0,0,0
	dw	0,0,0,0,7,0,0,0,0,0,0,7,0,0,0,0
	dw	0,0,0,0,0,7,7,7,7,7,7,0,0,0,0,0
	dw	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0

;
; ==================== Colour Tests =======================================
;
; Any GSX driver that supports colour should be able to cope with a request
; to reassign colours -- either by reprogramming palette registers, if
; the system has them, or just changing what colour is used in future drawing
; operations. In practice there are drivers which don't.
;
colrmenu:
	lxi	h,colrmenu
	shld	curmenu
	lxi	d,colms	
	call	print
cloop:	call	getkeyu
	cpi	3
	jz	exit
	cpi	1Bh
	jz	menu
	cpi	'M'
	jz	menu
	cpi	'1'
	jz	colr1
	cpi	'2'
	jz	colr2
	cpi	'3'
	jz	colr3
	cpi	'4'
	jz	colr4
	cpi	'5'
	jz	colr5
	jmp	cloop
;
; Colour test 5 is an attempt to display all possible colours (or as many
; as can be drawn). The bottom half will draw lines using all GSX colour
; numbers. The top half will draw using the same GSX colour number (2) 
; remapping it to a new RGB value each time.
;
colr5:	lhld	device
	call	vopnwk
	mvi	a,1		;Select solid line
	call	vslstyle
	lxi	h,0		;Set up for a line from Y=0 to Y=3FFFh
	shld	c5line
	shld	c5line+2
	shld	c5line+4
	lxi	h,3FFFh
	shld	c5line+6
;
; Draw the bottom half of the screen, as a series of vertical lines one in
; each supported colour
;	
	lxi	h,0
c5a:	push	h
	call	rrhl	;Divide by 2, so each ink is used for two lines
	shld	intin	;Go through all the inks
	pop	h
	inx	h
	push	h
	lxi	h,17	;Set line colour
	call	gsxcall	
	lxi	d,2
	lxi	h,c5line
	call	vpline	;Draw the line	
	lhld	minlw	
	xchg
	lhld	c5line	;Add min line width to the X coordinates
	dad	d
	shld	c5line
	shld	c5line+4
	mov	a,h	;Keep going until we hit the right-hand edge of the 
	cpi	80h	;screen
	pop	h
	jc	c5a
;
; Now for the top half, drawing in colour 2 but remapping that colour each
; time
;
	lxi	h,2		;Get actual colour 2
	lxi	d,1
	call	vqcolor
	lxi	h,intout+2	;Save its RGB values into c5def
	lxi	d,c5def
	lxi	b,6
	call	doldir

	lxi	h,0		
	shld	c5pal		;Start off at R=G=B=0	
	shld	c5pal+2
	shld	c5pal+4
	shld	c5line		;Set coordinates for a line from Y=4000h 
	shld	c5line+4	;to Y=7FFFh
	lxi	h,4000h
	shld	c5line+2
	lxi	h,7FFFh
	shld	c5line+6
	mvi	a,2		;Set line colour 2
	call	vslcolor
c5b:	lxi	d,2
	lxi	h,c5pal		;Set RGB for colour 2
	call	vscolor
	lxi	d,100		;Bump the RGB values
	lhld	c5pal+4
	call	add1000
	shld	c5pal+4
	jc	c5c
	lhld	c5pal+2
	call	add1000
	shld	c5pal+2
	jc	c5c
	lhld	c5pal
	call	add1000
	shld	c5pal
c5c:	lxi	d,2		;Draw the line	
	lxi	h,c5line
	call	vpline	
	lhld	minlw		;Move right by minlw
	xchg
	lhld	c5line
	dad	d
	shld	c5line
	shld	c5line+4
	mov	a,h		;Until we hit the RH side of the screen
	cpi	80h
	jc	c5b
;
; Restore the mapping of colour 2 
;
	lxi	d,2
	lxi	h,c5def
	call	vscolor

	jmp	tableau

;
; Add DE to HL and return carry set if below 1000
;
add1000:
	dad	d
	mov	a,h
	cpi	3
	rc
	mov	a,l
	cpi	0E8h	
	rc	
	lxi	h,0
	ret
;
	dseg
c5line:	dw	0,0
	dw	0,4000h
c5pal:	dw	0,0,0
c5def:	dw	0,0,0
	cseg	
;
; Colour test 4: What happens if you change the colour mapping? Depending if 
; the display has palette registers, it might change the colours of what's 
; already drawn, or just affect what colour is used for drawing going forward.
; So this test draws a list of colours, switches the colour mapping, and 
; draws a second list.
;
colr4:	lhld	device
	call	vopnwk
	lxi	h,defpal	;Use the default palette when printing colour
	shld	colxlt		;names
	call	backg
	lxi	h,0
	call	colrc		;Print one list of colours in the default
				;palette...
	call	pal3270		;Then select the 3270 colours...
	lxi	h,4000h		;And print a second colour list.
	call	colrc		;On a truecolour display this will leave the
				;existing colours unaffected. On a paletted
	jmp	tableau		;display they will change to match.
;
pal3270:
	lxi	h,pc3270	;Use the 3270 palette when printing colour
	shld	colxlt		;names.
	mvi	c,8
	lxi	h,pc32req	;Program the first 8 colours with the 3270 
p3270a: mov	e,m		;palette
	inx	h
	mov	d,m
	inx	h
	call	vscolor
	lxi	d,6
	dad	d
	dcr	c
	jnz	p3270a
	ret
;
; Colour tests 1, 2 and 3 have a lot of code in common. They just set the
; palette up differently at the beginning.
;
; Test 3: Select the 3270 palette, and print the colour names
;
colr3:	lhld	device
	call	vopnwk
	lxi	h,pc3270
	shld	colxlt
	mvi	c,8
	lxi	h,pc32req
	jmp	colr2a
;
; Test 2: Select the DR-Graph palette, and print the colour names
;
colr2:	lhld	device
	call	vopnwk
	lxi	h,drdraw
	shld	colxlt
	mvi	c,8
	lxi	h,drdreq
colr2a:
	mov	e,m
	inx	h
	mov	d,m
	inx	h
	call	vscolor
	lxi	d,6
	dad	d
	dcr	c
	jnz	colr2a
	jmp	colr1a
;
; Test 1 doesn't reprogram the palette, just shows the colours using the
; defaults
;
colr1:	lhld	device
	call	vopnwk
	lxi	h,defpal
	shld	colxlt
colr1a:	call	backg
	lxi	h,0
	call	colrc
	jmp	tableau
;
; Dump current palette. colxlt holds palette names, X0 holds X-coord to 
; display at. 
;
colrc:	shld	x0
	lhld	minchy		;Set text height to default (minimum)
	call	vstheight
	lhld	csize+2		;That gives actual height of cell
	lxi	d,7C00h
	call	subdehl		;Start at the top and work down
	shld	y0
	lxi	h,0
	mvi	c,16		;Print 16 entries. GSX only defines 8 
colr1b:	push	b		;colours by default so colours 8+ should 
	push	h		;be white.
	lhld	x0
	shld	ptsin
	lhld	y0
	shld	ptsin+2
	pop	h
	call	showcol
	push	h
	lhld	y0
	lxi	d,-800h
	dad	d
	shld	y0
	pop	h
	inx	h
	pop	b
	dcr	c
	jnz	colr1b			
	ret
;
	dseg
colxlt:	dw	0
;
; Default palette order
;
defpal:	db	'Black   '
	db	'Red     '
	db	'Green   '
	db	'Blue    '
	db	'Cyan    '
	db	'Yellow  '
	db	'Magenta '
	db	'White   '
defwht:	db	'(white) '
;
; Palette to request for DR Graph
;
drdreq:
	dw	0,   0,   0,   0
	dw	1,1000,1000,1000
	dw	2,1000,   0,   0
	dw	3,   0,1000,   0
	dw	4,   0,   0,1000
	dw	5,   0,1000,1000
	dw	6,1000,1000,   0
	dw	7,1000,   0,1000
;
drdraw:	db	'Black   '
	db	'White   '
	db	'Red     '
	db	'Green   '
	db	'Blue    '
	db	'Cyan    '
	db	'Yellow  '
	db	'Magenta '
;
;
; Palette to request for 3270PC
;
pc32req:
	dw	0,   0,   0,   0
	dw	1, 952, 952, 761
	dw	2,1000, 285,   0
	dw	3,   0, 761,   0
	dw	4, 571, 761,1000 
	dw	5, 571,1000,1000 
	dw	6,1000, 500,   0
	dw	7,1000, 571, 761
;
pc3270:	db	'Black   '
	db	'White   '
	db	'Red     '
	db	'Green   '
	db	'Blue    '
	db	'Cyan    '
	db	'Yellow  '
	db	'Pink    '

	cseg
;
; Show requested and actual RGB for a colour
;
showcol:
	push	psw
	push	b
	push	d
	push	h 	;HL = colour
	mov	a,l
	call	vstcolor

	push	h
	lxi	d,txtmsg
	call	mdechl	;Write colour into message
	mvi	a,' '
	stax	d
	inx	d	;Colon follows colour
	pop	h
	mov	a,l
	cpi	8	;Any colour > 8 defaults to white
	jc	colexp
	lxi	h,defwht
	jmp	colcpy

colexp:	dad	h	;*2
	dad	h	;*4
	dad	h	;*8
	push	h
	lhld	colxlt
	pop	b
	dad	b	;->translated colour name
colcpy:	mvi	c,8
sc1a:	mov	a,m
	stax	d
	inx	h
	inx	d
	dcr	c
	jnz	sc1a	

	mvi	a,':'
	stax	d
	inx	d	;Colon follows colour
	pop	h
	push	h
	push	d	;Write pointer
	lxi	d,0
	call	vqcolor	; Get requested RGB
	pop	d
	jz	nocol
	
	lhld	intout
	call	mdechl
	mvi	a,';'
	stax	d
	inx	d	
	call	addrgb
	mvi	a,'='
	stax	d
	inx	d	
	mvi	a,'>'
	stax	d
	inx	d
	
	pop	h	;Colour
	push	h
	push	d
	lxi	d,1
	call	vqcolor	; Get actual RGB
	pop	d
	call	addrgb	
	xra	a
	stax	d
	jmp	scole
;
nocol:	lxi	h,ncmsg
	lxi	b,ncmse-ncmsg
	call	doldir
scole:	lxi	h,txtmsg
	call	vatext		;
	pop	h
	pop	d
	pop	b
	pop	psw
	ret
;
addrgb:	lhld	intout+2
	call	mdechl
	mvi	a,','
	stax	d
	inx	d
	lhld	intout+4
	call	mdechl
	mvi	a,','
	stax	d
	inx	d
	lhld	intout+6
	jmp	mdechl
		
	dseg
ncmsg:	db	'No colour mapping',0
ncmse:
	cseg
;
; HL := DE - HL
;
subdehl:
	mov	a,d
	sub	h
	mov	h,a
	mov	a,e
	sbb	l
	mov	l,a
	ret
;
; ==================== Area Fill Tests ====================================
;
; Fill tests. Colour/write modes for the four main fill styles (hollow, 
; solid, shaded, hatched) and a fifth that tries to show all possible styles
; of fill on one screen.
;
fillmenu:
	lxi	h,fillmenu
	shld	curmenu
	lxi	d,fills
	call	print
floop:	call	getkeyu
	cpi	3
	jz	exit
	cpi	1Bh
	jz	menu
	cpi	'1'
	jz	fill1
	cpi	'2'
	jz	fill2
	cpi	'3'
	jz	fill3
	cpi	'4'
	jz	fill4
	cpi	'5'
	jz	fill5
	cpi	'M'
	jz	menu
	jmp	floop
;
;
fill5:	lhld	device		;Draw all fill styles etc in octagons
	call	vopnwk
	call	backg
	call	fill5body
	jmp	tableau
;
; The body of this test is a separate function because I also use it in
; other tests.
;
fill5body:
	xra	a
	call	vswrmode

	mvi	a,1
	call	vslstyle
	mvi	a,WHITE
	call	vsfcolor
	lxi	h,0
	shld	x0
	shld	y0
	lxi	b,0		;B = interior 0-3, C=style
fill5a:
	push	b
	mov	a,b
	call	vsfinterior
	pop	b
	push	b
	mov	a,c
	call	vsfstyle
	call	vfoct		;Draw octagon
	lhld	x0
	lxi	d,1000h		;Move to next X position
	dad	d
	mov	a,h
	cpi	7Fh
	jc	fill5b		;Hit edge of screen?
	lhld	y0
	dad	d		;If so reset X, increment Y
	mov	a,h
	cpi	7Fh
	pop	b
	jnc	tableau		;If hit top of screen, break out of loop
	push	b
	shld	y0
	lxi	h,0
fill5b:
	shld	x0
;
; Now to move to next pattern
;	
	pop	b
	call	nxtpat
	mov	a,b		;When we reach interior 4 (which would be a 
	cpi	4		;user-defined pattern in GEM) stop
	jc	fill5a
	ret
;
; For B=fill interior C=style move to next valid combination
;
nxtpat:
	mov	a,b
	ora	a		;Fill interior 0 has no styles
	jz	npat2
	dcr	a		;Nor does fill interior 1
	jz	npat2
	dcr	a		;Fill interior 2 has patrns patterns
	lhld	patrns
	jz	npat1		;
	lhld	hatches		;Interior 3 has hatches patterns
npat1:	mov	a,c		;Fill style
	cmp	l
	jnc	npat2		;Reached end of that range
	inr	c
	ret
;
npat2:	inr	b		;Increment fill interior
	mvi	c,1		;Reset fill style
	ret
;
; The other 4 fill tests draw the same pattern, just using a different
; style (hollow / solid / shaded / hatched) A selects which.
;
fill4:
	mvi	a,3
	db	21h	;LXI H, (swallows 2 bytes)
fill3:	mvi	a,2
	db	21h	;LXI H, (swallows 2 bytes)
fill2:	mvi	a,1
	db	2Eh	;MVI L, (swallows 1 byte)
fill1:	xra	a
	push	psw
	lhld	device
	call	vopnwk
	call	backg

	mvi	a,1
	call	vslstyle
	pop	psw
	call	vsfinterior
	mvi	a,3
	call	vsfstyle

	lxi	h,0
	shld	x0
	shld	y0

	mvi	b,8
	lxi	d,1000h
	xra	a
tfcol:	call	vsfcolor
	inr	a
	lxi	h,0
	shld	x0
	push	psw
	mvi	c,8
	xra	a
tfrow:	ani	3
	inr	a
	call	vswrmode	
	call	vfstar
	dad	d
	shld	x0
	dcr	c
	jnz	tfrow
	pop	psw
	lhld	y0
	dad	d
	shld	y0
	dcr	b
	jnz	tfcol
	
	xra	a
	call	vswrmode
	jmp	tableau
;
;
; Draw a pentagonal star at X0,Y0
;
vfstar:
	push	h
	push	d
	push	b
	push	psw

	lxi	h,star
	lxi	d,ptsin	;Send translated coords to ptsin
	mvi	b,6
vfstar1:
	call	copypt
	dcr	b
	jnz	vfstar1
	lxi	h,5
	shld	nptsin
	lxi	h,9	;v_fillarea
	call	gsxcall	
	
	pop	psw
	pop	b
	pop	d
	pop	h
	ret
;
;
; Draw an octagon at X0,Y0
;
vfoct:
	push	h
	push	d
	push	b
	push	psw

	lxi	h,octagon
	lxi	d,ptsin	;Send translated coords to ptsin
	mvi	b,9
vfoct1:
	call	copypt
	dcr	b
	jnz	vfoct1
	lxi	h,8
	shld	nptsin
	lxi	h,9	;v_fillarea
	call	gsxcall	
	
	pop	psw
	pop	b
	pop	d
	pop	h
	ret
;
; ==================== General Drawing Primitive Tests ====================
;
; In theory all GSX drivers should support at least the bar GDP. Support 
; for the others is patchier.
;
gdpmenu:
	lxi	h,gdpmenu
	shld	curmenu
	lxi	d,gdpms
	call	print
gloop:	call	getkeyu
	cpi	3
	jz	exit
	cpi	1Bh
	jz	menu
	cpi	'1'
	jz	bar1
	cpi	'2'
	jz	bar2
	cpi	'3'
	jz	bar3
	cpi	'4'
	jz	arc1
	cpi	'5'
	jz	arc2
	cpi	'6'
	jz	arc3
	cpi	'7'
	jz	pie1
	cpi	'8'
	jz	pie2
	cpi	'9'
	jz	circle1
	cpi	'A'
	jz	circle2
	cpi	'M'
	jz	menu
	jmp	gloop
;
; The bar tests are based on the fill tests, just using a rectangle rather 
; than a star / octagon.
;
bar1:	lhld	device
	call	vopnwk
	call	backg

	mvi	a,1
	call	vslstyle
	mvi	a,2		;Draw the bar with a shaded interior
	call	vsfinterior	
	mvi	a,4		;(choice of 4 was arbitrary)
	call	vsfstyle

	lxi	h,0
	shld	x0
	shld	y0

	mvi	b,8
	lxi	d,1000h
	xra	a
obcol:	call	vsfcolor
	inr	a
	lxi	h,0
	shld	x0
	push	psw
	mvi	c,8
	xra	a
obrow:	ani	3
	inr	a
	call	vswrmode	
	call	vpbar
	dad	d
	shld	x0
	dcr	c
	jnz	obrow
	pop	psw
	lhld	y0
	dad	d
	shld	y0
	dcr	b
	jnz	obcol
	
	xra	a
	call	vswrmode
	jmp	tableau
;
; This is a clone of fill test 5, to draw bars with all possible fill styles
; and patterns
;
bar2:	lhld	device		;
	call	vopnwk
	call	backg
	xra	a
	call	vswrmode

	mvi	a,1
	call	vslstyle
	mvi	a,WHITE
	call	vsfcolor
	lxi	h,0
	shld	x0
	shld	y0
	lxi	b,0		;B = interior 0-3, C=style
bar2a:	push	b
	mov	a,b
	call	vsfinterior
	pop	b
	push	b
	mov	a,c
	call	vsfstyle
	call	vpbar		;Draw bar
	lhld	x0
	lxi	d,1000h		;Move to next X position
	dad	d
	mov	a,h
	cpi	7Fh
	jc	bar2b		;Hit edge of screen?
	lhld	y0
	dad	d		;If so reset X, increment Y
	mov	a,h
	cpi	7Fh
	pop	b
	jnc	tableau		;If hit top of screen, break out of loop
	push	b
	shld	y0
	lxi	h,0
bar2b:
	shld	x0
;
; Now to move to next pattern
;	
	pop	b
	call	nxtpat
	mov	a,b		;When we reach interior 4 (which would be a 
	cpi	4		;user-defined pattern in GEM) stop
	jc	bar2a
	jmp	tableau
;
; Bar test 3 is to draw bars in all possible colours (or as many as will 
; fit if the display happens to support >64 colours)
;
bar3:	lhld	device		;Draw bars in different colours 
	call	vopnwk
	call	backg
	xra	a
	call	vswrmode

	mvi	a,1
	call	vslstyle
	mvi	a,1
	call	vsfinterior	;Solid fill
	lxi	h,0
	shld	x0
	shld	y0
	xra	a
bar3a:	call	vsfcolor	;Set fill colour
	inr	a
	push	psw
	call	vpbar		;Draw bar
	lhld	x0
	lxi	d,1000h		;Move to next X position
	dad	d
	mov	a,h
	cpi	7Fh
	jc	bar3b		;Hit edge of screen?
	lhld	y0
	dad	d		;If so reset X, increment Y
	mov	a,h
	cpi	7Fh
	pop	b
	jnc	tableau		;If hit top of screen, break out of loop
	push	b
	shld	y0
	lxi	h,0
bar3b:	shld	x0
;
; Now to move to next colour
;
	lhld	dcolrs
	mov	a,h
	ora	a
	jnz	bar3c
		
	pop	psw		;A = next colour to use
	cmp	l		;Is it less than max?
	jc	bar3a
	jmp	tableau
;
bar3c:	pop	psw
	jmp	bar3a
;
;
; Draw GDP bar at x0,y0
;
vpbar:
	push	h
	push	d
	push	b
	push	psw

	lxi	h,bar0	;Bar shape
	lxi	d,ptsin	;Send translated coords to ptsin
	call	copypt
	call	copypt
	lxi	h,2
	shld	nptsin
	lxi	h,1
	shld	contrx
	lxi	h,11	;v_gdp
	call	gsxcall	
	
	pop	psw
	pop	b
	pop	d
	pop	h
	ret
;
; The arc, circle and pie tests all use similar data and share the same code
;
circle1:
	lxi	h,4	;Circle GDP
	jmp	arc1c	
;
pie1:	lxi	h,3	;Pie slice GDP
	jmp	arc1c

arc1:	lxi	h,2	;Arc GDP
arc1c:	shld	arctype
	lhld	device
	call	vopnwk
	call	backg

	mvi	a,1
	call	vslstyle
	mvi	a,WHITE
	call	vsfcolor
	lxi	h,0
	shld	x0
	shld	y0

	mvi	b,8
	lxi	d,1000h
	xra	a
arc1a:	call	vsfcolor
	inr	a
	lxi	h,0
	shld	x0
	push	psw
;
; In case we're going to draw a filled shape, select a hatched interior
;
	mvi	a,3		;Pick a hatched interior for the bar 
	call	vsfinterior	;(more or less at random)
	mvi	a,6
	call	vsfstyle

	mvi	c,8
	xra	a
arc1b:	ani	3
	inr	a
	call	vswrmode	
	call	varctest	;Draw the shape
	lhld	x0
	dad	d
	shld	x0
	dcr	c
	jnz	arc1b
	pop	psw
	lhld	y0
	dad	d
	shld	y0
	dcr	b
	jnz	arc1a
	
	xra	a
	call	vswrmode
	jmp	tableau
;
; Same for here: circle, pie and arc tests all share the same outer loop
;
circle2:
	lxi	h,4
	jmp	arc2c	
;
pie2:	lxi	h,3
	jmp	arc2c

arc2:	lxi	h,2
arc2c:	shld	arctype
	lhld	device
	call	vopnwk
	call	backg
	mvi	a,2		;Pick a hatched interior in case we are 
	call	vsfinterior	;doing pie slices
	mvi	a,WHITE
	call	vsfcolor

	lxi	h,0
	shld	x0
	shld	y0

	mvi	b,8
	lxi	d,1000h
	xra	a
arc2a:	inr	a
	call	vslstyle
	call	vsfstyle
	lxi	h,0
	shld	x0
	push	psw
	mvi	c,8
	xra	a
arc2b:	ani	3
	inr	a
	call	vswrmode	
	call	varctest
	lhld	x0
	dad	d
	shld	x0
	dcr	c
	jnz	arc2b
	pop	psw
	lhld	y0
	dad	d
	shld	y0
	dcr	b
	jnz	arc2a
	
	xra	a
	call	vswrmode
	jmp	tableau
;
; Arc test 3 (varying line widths) has no equivalent for filled shapes, so 
; there are no pie slice / circle versions of it.
;
arc3:	lxi	h,2
	shld	arctype
	lhld	device
	call	vopnwk
	call	backg

	lxi	h,0
	shld	x0
	shld	y0

	lhld	lwidths	;BC = line widths
	mov	b,h
	mov	c,l
	lhld	maxlw	;Max line width
	xchg		;DE = max line width
	lhld	minlw	;HL = min line width
	push	h
	call	calcsteps
	pop	d	;DE = line width, HL = increment
	mvi	b,8
arc3a:	push	h
	push	d
	xchg
	call	vslwidth
	lxi	h,0
	shld	x0
	mvi	c,8
	xra	a
arc3b:	ani	3
	inr	a
	call	vswrmode	
	call	varctest
	lhld	x0
	lxi	d,1000h
	dad	d
	shld	x0
	dcr	c
	jnz	arc3b
	lhld	y0
	dad	d
	shld	y0
	pop	d
	pop	h
	xchg
	dad	d	;Add increment to width
	xchg
	dcr	b
	jnz	arc3a
	
	xra	a
	call	vswrmode
	jmp	tableau
;
;
;
; Draw arc (or pie slice) test pattern at x0,y0
;
	dseg
arctype:
	dw	0		;Drawing an arc or a pie slice?
varcdata:
	dw	100h,100h	;Centre point of arc
	dw	0E00h,200h	;Start point of arc
	dw	200h,0E00h	;End point of arc
radius:	dw	0D0Ah, 0	;Radius
;
; Start angle is arctan(1/14) = 4.09°. End angle is arctan(14/1)=85.91°
;
varctest:
	push	h
	push	d
	push	b
	push	psw


	lxi	h,varcdata
	lxi	d,ptsin	;Send translated coords to ptsin
	call	copypt	;First point is the centre
	call	copypt	;Second is start point of arc / point on circle rim
	call	copypt	;Third is end point of arc
	lhld	radius	;Fourth is radius
	shld	ptsin+12
	lda	arctype
	cpi	4
	jnz	varct1
	call	rrhl
	shld	ptsin+8	;If drawing a circle, there is no third point,
varct1:			;so move the radius to point 3 and halve it
	lxi	h,0
	shld	ptsin+14
	lxi	h,4
	shld	nptsin
	lxi	h,2
	shld	nintin	;2 integers incoming
	lhld	arctype
	shld	contrx	;Select arc / pie slice / circle primitive
	lxi	h,41
	shld	intin
	lxi	h,859	;Start and end angle (for arc / pie slice)
	shld	intin+2
	lxi	h,11	;GDP
	call	gsxcall	
	
	pop	psw
	pop	b
	pop	d
	pop	h
	ret
;
; ==================== Input Tests ========================================
;
; GSX drivers, if they implement any input devices at all, tend to be 
; limited to locator input. So the tests for other input types are pretty
; theoretical.
;
; GSX allows multiple input devices per driver, so we have to cater for that
; as well.
;
inpmenu:
	lxi	h,inpmenu
	shld	curmenu	
	call	prcrlf
	lxi	d,inpdevm	;Show the current input device
	call	print
	lhld	inpdev
	call	dechl
	call	prcrlf
	lxi	d,inputs	;Then the menu as usual
	call	print
iloop:	call	getkeyu
	cpi	3
	jz	exit
	cpi	1Bh
	jz	menu
	cpi	'1'		;We have two tests for each device type:
	jz	inp1
	cpi	'2'		;request mode and sample mode
	jz	inp2
	cpi	'3'
	jz	inp3
	cpi	'4'
	jz	inp4
	cpi	'5'
	jz	inp5
	cpi	'6'
	jz	inp6
	cpi	'7'
	jz	inp7
	cpi	'8'
	jz	inp8
	cpi	'D'	;D changes device number
	jz	idevd
	cpi	'M'
	jz	menu
	jmp	iloop
;
; Locator test (request mode)
;
inp1:	lhld	device
	call	vopnwk

	lxi	b,locmsg	;Check that the locator device number is in
	lhld	nlocs		;range. If not, go no further
	call	rgcheck
	jnc	tableau

	call	backg
	call	fill5body	;Draw the test pattern from fill test 5
	call	text5body	;Superimpose the text from text test 5
	lxi	h,1		;Locator
	lxi	d,1		;Request mode
	call	vsinmode	
	lhld	inpdev
	shld	intin
	lxi	h,4000h		;Start off in the middle of the screen
	shld	ptsin
	shld	ptsin+2
	lxi	h,1
	shld	nintin
	shld	nptsin
	lxi	h,28		;Read locator. This will return when a selection
	call	gsxcall		;is made.
	call	showloc		;Show the result of the selection.
	jmp	tableau
;
; Locator test (sample mode)
;
inp2:	lhld	device
	call	vopnwk

	lxi	b,locmsg	;Range check as above
	lhld	nlocs
	call	rgcheck
	jnc	tableau

	call	backg
	call	fill5body	;Draw the test pattern from fill test 5
	call	text5body	;Superimpose the text from text test 5
	lxi	h,1		;Locator
	lxi	d,2		;Sample mode
	call	vsinmode	
	lxi	h,4000h
	shld	x0
	shld	y0
inp2a:	lhld	inpdev		;This time we need to handle the input loop
	shld	intin
	lhld	x0
	shld	ptsin
	lhld	y0
	shld	ptsin+2
	lxi	h,1
	shld	nptsin
	lxi	h,1
	shld	nintin
	lxi	h,28		;Read locator
	call	gsxcall
	lhld	nptsot		;Did it return a point?
	mov	a,h
	ora	l
	jz	inp2b
	lhld	ptsout		;If so save it as the starting point for the
	shld	x0		;next sample
	lhld	ptsout+2
	shld	y0
inp2b:
	call	showloc		;Show the results of the input
	mvi	c,CDIRECT	;Poll the keyboard, and if they press 
	mvi	e,0ffh		;escape finish the loop.
	call	FDOS
	cpi	1Bh
	jz	tableau
	cpi	03h
	jz	tableau
	jmp	inp2a
;
; Valuator input. I haven't been able to test this; it's just based on 
; a cut-down copy of the locator tests.
;
inp3:	lhld	device
	call	vopnwk

	lxi	b,valmsg
	lhld	nvals
	call	rgcheck
	jnc	tableau

	lxi	h,2		;Valuator
	lxi	d,1		;Request mode
	call	vsinmode	
	lhld	inpdev
	shld	intin
	lxi	h,100		;Start off randomly at 100
	shld	intin+2
	lxi	h,0
	shld	nptsin
	lxi	h,2
	shld	nintin
	lxi	h,29		;Read valuator
	call	gsxcall
	call	showval
	jmp	tableau
;
; Same for valuator sample
;
inp4:	lhld	device
	call	vopnwk

	lxi	b,valmsg
	lhld	nvals
	call	rgcheck
	jnc	tableau

	lxi	h,2		;Valuator
	lxi	d,2		;Sample mode
	call	vsinmode	
inp4a:	lhld	inpdev
	shld	intin
	lxi	h,0
	shld	nptsin
	lxi	h,1
	shld	nintin
	lxi	h,29		;Read valuator
	call	gsxcall
	call	showval
	mvi	c,CDIRECT	;Poll keyboard for end
	mvi	e,0ffh
	call	FDOS
	cpi	1Bh
	jz	tableau
	cpi	03h
	jz	tableau
	jmp	inp4a
;
; And again, the choice test is written purely on theoretical info.
;
inp5:	lhld	device
	call	vopnwk

	lxi	b,chcmsg	;Check that the device is in range
	lhld	nchcs
	call	rgcheck
	jnc	tableau

	lxi	h,3		;Choice
	lxi	d,1		;Request mode
	call	vsinmode	
	lhld	inpdev
	shld	intin
	lxi	h,0
	shld	nptsin
	lxi	h,1
	shld	nintin
	lxi	h,30		;Read choice
	call	gsxcall
	call	showchc
	jmp	tableau
;
; Polling version of choice test
;
inp6:	lhld	device
	call	vopnwk

	lxi	b,chcmsg
	lhld	nchcs
	call	rgcheck
	jnc	tableau

	lxi	h,3		;Choice
	lxi	d,2		;Sample mode
	call	vsinmode	
inp6a:	lhld	inpdev
	shld	intin
	lxi	h,0
	shld	nptsin
	lxi	h,1
	shld	nintin
	lxi	h,30		;Read choice
	call	gsxcall
	call	showchc
	mvi	c,CDIRECT	;Poll keyboard for end
	mvi	e,0ffh
	call	FDOS
	cpi	1Bh
	jz	tableau
	cpi	03h
	jz	tableau
	jmp	inp6a
;
; String input tests
;
inp7:	lhld	device
	call	vopnwk
	lxi	h,4		;String
	lxi	d,1		;Request mode
	call	vsinmode	
	lhld	inpdev
	shld	intin
	lxi	h,20
	shld	intin+2		;Max length 20
	lxi	h,1
	shld	intin+4		;Echo on
	lxi	h,0
	shld	ptsin
	lxi	h,4000h
	shld	ptsin+2		;Echo location
	lxi	h,1
	shld	nptsin
	lxi	h,3
	shld	nintin
	lxi	h,31		;Read string
	call	gsxcall
	call	showstr
	jmp	tableau
;
inp8:	lhld	device
	call	vopnwk
	lxi	h,4		;String
	lxi	d,2		;Sample mode
	call	vsinmode	
inp8a:	lhld	inpdev
	shld	intin
	lxi	h,20
	shld	intin+2
	lxi	h,0
	shld	nptsin
	lxi	h,2
	shld	nintin
	lxi	h,31		;Read string
	call	gsxcall
	call	showstr
	mvi	c,CDIRECT	;Poll keyboard for end
	mvi	e,0ffh
	call	FDOS
	cpi	1Bh
	jz	tableau
	cpi	03h
	jz	tableau
	jmp	inp8a
;
; Common to all input tests: Check that the device number is in range. 
; BC=message HL=max device number. Returns carry set if OK, carry clear 
; if out of range
;
rgcheck:
	mov	a,h	;If HL=0 there are no available devices of that class
	ora	l
	jz	rgnone
	xchg		;DE = max devices
	lhld	inpdev	;HL = current device
	mov	a,h
	cmp	d
	jz	rgcheck1 ;If H = D go to checking E
	rc		;If H < D we are OK 
	jmp	rgoor	;If H > D it's not valid
rgcheck1:
	mov	a,l
	cmp	e	;If L = E it's in range
	jz	rgok	
	jnc	rgoor	;If L > E it's not valid
rgok:	stc
	ret
;
; Report that the device number is out of range
;
rgoor:
	lxi	h,0
	shld	ptsin
	lxi	h,4000h
	shld	ptsin+2
	lxi	h,rgmsg4
	call	vatext	
	ana	a
	ret
;
; Report that there are no devices of the right type
;
rgnone:	push	b		;Device type
	lxi	d,81h		;Build message at 81h.
	lxi	h,rgmsg1
	lxi	b,rgmsg2-rgmsg1
	call	doldir		;Copy the first part (rgmsg1)
	pop	h
rgcpy:	mov	a,m		;Copy the variable part of the message (device
	stax	d		;type)
	inx	h
	inx	d
	ora	a
	jnz	rgcpy
	dcx	d		;Then append the second part of the message
	lxi	h,rgmsg2	;(rgmsg2)
	lxi	b,rgmsg3-rgmsg2
	call	doldir
	lxi	h,0
	shld	ptsin		;And display that on the graphics screen
	lxi	h,4000h
	shld	ptsin+2
	lxi	h,81h
	call	vatext	
	ana	a
	ret
;
	dseg
rgmsg1:	db	'No '
rgmsg2:	db	' input devices present',0
rgmsg3:
rgmsg4: db	'Input device number out of range',0

locmsg:	db	'locator',0
valmsg:	db	'valuator',0
chcmsg:	db	'choice',0

;
; Display the result(s) of a locator test 
;
showloc:
	lhld	nptsot	;Any points returned?
	mov	a,h
	ora	l
	jz	sloc3	;If not, skip this bit
	lxi	d,81h
	lxi	h,iresult
	lxi	b,irs1-iresult
	call	doldir	;Build a message at 81h showing locator coordinates
	lhld	ptsout
	call	mdechl	;X
	mvi	a,','
	stax	d
	inx	d
	lhld	ptsout+2	;Y
	call	mdechl
	mvi	b,10
	mvi	a,' '	;Append 10 spaces to overwrite any previous result
pack:	stax	d
	inx	d
	dcr	b
	jnz	pack	
	xra	a
	stax	d	
	lhld	intout	;Get the intout value returned from locator read
	push	h	;and save it	
	lhld	nintot	;Get the intout count returned
	push	h	;and save that too
	lxi	h,0
	shld	ptsin
	lxi	h,4000h
	shld	ptsin+2
	lxi	h,81h	;Draw the coordinates
	call	vatext
	pop	h	;Restore the intout count and value.
	shld	nintot
	pop	h
	shld	intout
sloc3:	lhld	nintot	;If anything was returned in intout, show it
	mov	a,h
	ora	l
	rz
	lxi	d,81h
	lxi	h,irs2
	lxi	b,irs3-irs2
	call	doldir	
	lhld	intout
	call	mdechl
	xra	a
	stax	d
	lxi	h,4000h
	shld	ptsin
	shld	ptsin+2
	lxi	h,81h
	jmp	vatext
;
;
; Display the result(s) of a valuator test.
;
showval:
	lxi	d,81h		;Start with fixed text
	lxi	h,vresult
	lxi	b,vrs1-vresult
	call	doldir
	lhld	intout		;Append value in intout
	call	mdechl
	mvi	b,5		;Pad with spaces to overwrite any previous
	mvi	a,' '		;result
vpack:	stax	d
	inx	d
	dcr	b
	jnz	vpack	
	xra	a
	stax	d	
	lhld	intout
	push	h	
	lhld	nintot	;Save the intout result through the vatext call
	push	h
	lxi	h,0
	shld	ptsin
	lxi	h,4000h
	shld	ptsin+2
	lxi	h,81h
	call	vatext
	pop	h
	shld	nintot
	pop	h
	shld	intout
	lxi	d,81h
	lxi	h,irs2
	lxi	b,irs3-irs2
	call	doldir	
	lhld	intout+2
	call	mdechl
	xra	a
	stax	d
	lxi	h,4000h
	shld	ptsin
	shld	ptsin+2
	lxi	h,81h
	jmp	vatext

;
;
; Display the result(s) of a choice test
;
showchc:
	lxi	d,81h
	lxi	h,vresult
	lxi	b,vrs1-vresult
	call	doldir
	lhld	nintot
	call	mdechl
	call	cpk
	lhld	intout+2
	push	h	
	lhld	intout
	push	h	
	lxi	h,0
	shld	ptsin
	lxi	h,4000h
	shld	ptsin+2
	lxi	h,81h
	call	vatext
	lxi	d,81h
	lxi	h,crs2
	lxi	b,crs3-crs2
	call	doldir	
	pop	h
	call	mdechl
	call	cpk
	lxi	h,2000h
	shld	ptsin
	lxi	h,4000h
	shld	ptsin+2
	lxi	h,81h
	call	vatext

	lxi	d,81h
	lxi	h,irs2
	lxi	b,irs3-irs2
	call	doldir	
	pop	h
	call	mdechl
	call	cpk
	lxi	h,6000h
	shld	ptsin
	lxi	h,4000h
	shld	ptsin+2
	lxi	h,81h
	jmp	vatext

cpk:	mvi	b,5
	mvi	a,' '
cpack:	stax	d
	inx	d
	dcr	b
	jnz	cpack	
	xra	a
	stax	d	
	ret
;
;
; Display the result(s) of a string test
;
showstr:
	lxi	d,81h
	lxi	h,vresult
	lxi	b,vrs1-vresult
	call	doldir
	lhld	nintot
	shld	nintin
	push	h
	call	mdechl
	mvi	a,' '
	stax	d
	inx	d
	pop	b
	lxi	h,intout
shows1:	mov	a,b
	ora	c
	jz	shows3
shows2:	mov	a,m
	stax	d
	inx	h
	inx	h
	inx	d
	dcx	b
	jnz	shows2
shows3:	xra	a
	stax	d
	lxi	h,0
	shld	ptsin
	lxi	h,2000h
	shld	ptsin+2
	lxi	h,81h
	jmp	vatext

	dseg
vresult:db	'Result: '
vrs1:	db	0
iresult:
	db	'Coordinates: '
irs1:	db	0
irs2:	db	' Terminator='
irs3:	db	0
crs2:	db	' Choice='
crs3:	db	0
crs4:	db	' Key='
crs5:	db	0

	cseg
;
; Bump the device number used for input tests.
;
idevd:	lhld	inpdev
	inx	h
	shld	inpdev	;Increase by 1
	mov	a,l
	cpi	10	;If it's >= 10 wrap it back to 1
	jc	ideve
	lxi	h,1
	shld	inpdev
ideve:	lxi	d,inpdevm
	call	print	;Display the new device number
	lhld	inpdev
	call	dechl
	call	prcrlf
	jmp	iloop

;
; ==================== Text Output Tests ==================================
;
textmenu:
	lxi	h,textmenu
	shld	curmenu
	lxi	d,texts
	call	print
tloop:	call	getkeyu
	cpi	3
	jz	exit
	cpi	1Bh
	jz	menu
	cpi	'1'
	jz	text1
	cpi	'2'
	jz	text2
	cpi	'3'
	jz	text3
	cpi	'4'
	jz	text4
	cpi	'5'
	jz	text5
	cpi	'6'
	jz	text6
	cpi	'M'
	jz	menu
	jmp	tloop
;
	dseg
txtmet1: db	'Text metrics [$'
txtmet2: db	'] Char size: $'
txtmet3: db	'  Cell size: $'
txt0:	db	'0%  ->$'
txt100:	db	'100%->$'
txt150:	db	'150%->$'
txt200:	db	'200%->$'

a1:	db	'A1$'
a2:	db	'A2$'
a3:	db	'A3$'
a4:	db	'A4$'
a5:	db	'A5$'
	cseg
;
; Display text metrics for various sizes
;
text1:	lhld	device
	call	vopnwk
	lxi	d,wsize0	;Get metrics for size 0 (some programs do 
	lxi	h,0		;actually ask for size 0 meaning 'minimum')
	call	text1a
	lxi	d,wsize1	;Now for actual minimum size
	lhld	minchy	
	call	text1a
	lxi	d,wsize2
	lhld	minchy		;Now for 150% of minimum size
	mov	a,h		;Let BC = HL >> 1
	ana	a
	rar
	mov	b,a
	mov	a,l
	rar
	mov	c,a
	dad	b		;HL = HL * 1.5
	call	text1a		;For 150%
	lxi	d,wsize3
	lhld	minchy
	dad	h		;HL = HL * 2
	call	text1a		;For 200% of minimum size
	call	vclswk
;
	lxi	h,wsize0	;And display all of the above
	lxi	b,txt0
	call	text1b
	lxi	h,wsize1
	lxi	b,txt100
	call	text1b
	lxi	h,wsize2
	lxi	b,txt150
	call	text1b
	lxi	h,wsize3
	lxi	b,txt200
	call	text1b
	jmp	textmenu
;
; Get the metrics for a given text size
;
text1a: xchg
	mov	m,e		;Save requested size
	inx	h
	mov	m,d
	inx	h
	xchg
	push	d
	call	vstheight	;Request that size (metrics saved in wsize)

	lxi	h,wsize
	pop	d
	lxi	b,8
	jmp	doldir		;And copy the metrics to output address
;
; Display the metrics for a given text size (text screen)
;
text1b:	push	h
	push	b
	lxi	d,txtmet1	;Print 'text metrics for'
	call	print
	pop	d
	call	print		;Print requested size info
	pop	h
	call	decatm
	push	h
	lxi	d,txtmet2
	call	print
	pop	h
	call	decatm
	mvi	e,'x'
	call	echar
	call	decatm
	push	h
	lxi	d,txtmet3
	call	print
	pop	h
	call	decatm
	mvi	e,'x'
	call	echar
	call	decatm
	jmp	prcrlf	
;
; Write a character preserving HL
;
echar:	push	h
	mvi	c,CWRITE
	call	FDOS
	pop	h
	ret
;
; Print value at HL as decimal
;
decatm:
	mov	e,m
	inx	h
	mov	d,m		;DE = value to print
	inx	h
	push	h
	xchg			;HL = value to print
	call	dechl
	pop	h
	ret
;
; Text test 2: Colours and write modes
;
text2:
	lhld	device
	call	vopnwk
	call	backg
	lhld	minchy	;Select minimum height
	call	vstheight
	lxi	h,0
	shld	x0
	shld	y0

	mvi	b,8
	lxi	d,1000h
	xra	a	;Outer loop over colours
t2col:	sta	tcolor
	call	vstcolor
	inr	a
	lxi	h,0
	shld	x0
	push	psw
	mvi	c,8
	xra	a	;Inner loop over write modes
t2row:	ani	3
	inr	a
	sta	wrmode
	call	vswrmode	
	call	txttest2	
	lhld	x0
	dad	d
	shld	x0
	dcr	c
	jnz	t2row
	pop	psw
	lhld	y0
	dad	d
	shld	y0
	dcr	b
	jnz	t2col
	xra	a
	call	vswrmode
	jmp	tableau
;
; In the text test, it's possible to display what colour / write modes are in
; use rather than just have a fixed test pattern. 
;
txttest2:
	push	psw
	push	b
	push	d
	push	h
	lda	tcolor
;
; Generate a message of the form 'n mode' where n = colour
;
	adi	'0'
	sta	txtmsg
	lda	wrmode
	dcr	a
	ani	3
	mov	l,a
	mvi	h,0
	dad	h	;*2
	dad	h	;*4
	dad	h	;*8
	lxi	b,wmds
	dad	b	;HL->source message
	lxi	b,8
	lxi	d,txtmsg+1
	call	doldir
	xra	a
	stax	d	;Add terminating nul
	
	lhld	x0
	shld	ptsin
	lhld	y0
	shld	ptsin+2
	lxi	h,txtmsg
	call	vatext			
	pop	h
	pop	d
	pop	b
	pop	psw
	ret
;
	dseg
tht3:	dw	0	;Text height for test 3
thstep:	dw	0	;Step to increase it by
	cseg
;
; Text test 3 draws text bigger and bigger until we reach the edge of
; the screen.
;
text3:
	lhld	device
	call	vopnwk
	call	backg
	lhld	minchy		;Select minimum character height
	call	vstheight	;Find out what that actually is
	lhld	csize+2
	shld	tht3		;That's the starting height
	call	rrhl
	shld	thstep		;Increase by half of that each time
	lxi	h,0
	shld	x0
	lhld	wsize+2
	lda	csize+3		;Set initial Y position to csize - wsize
	sub	h		;(which should approximate to baseline)
	mov	h,a
	lda	csize+4
	sbb	l
	mov	l,a
	shld	y0

	xra	a		;Outer loop over heights
	call	vswrmode
t3loop:
	lhld	tht3
	call	vstheight
	xchg
	lhld	thstep
	dad	d
	shld	tht3
	lxi	h,0
	shld	x0
	push	psw
	mvi	c,4		;Inner loop over write modes
	xra	a
t3row:	ani	3
	inr	a
	sta	wrmode
	call	vswrmode	
	call	txttest3
	lxi	d,2000h
	lhld	x0
	dad	d
	shld	x0
	dcr	c
	jnz	t3row
	pop	psw
	push	d
	lhld	csize+2
	xchg
	lhld	y0
	dad	d
	pop	d
	shld	y0
	mov	a,h
	ani	80h	;Keep going until we hit the edge
	jz	t3loop
	xra	a
	call	vswrmode
	jmp	tableau
;
; The message printed in test 3 is requested size -> actual size
;
txttest3:
	push	psw
	push	b
	push	d
	push	h
	lhld	tht3	;Append requested size
	lxi	d,txtmsg
	call	mdechl
	mvi	a,'-'	;Append "->"
	stax	d
	inx	d
	mvi	a,'>'
	stax	d
	inx	d
	lhld	csize+2	;Append actual size
	call	mdechl
	xra	a
	stax	d
	
	lhld	x0	;And write that message
	shld	ptsin
	lhld	y0
	shld	ptsin+2
	lxi	h,txtmsg
	call	vatext			
	pop	h
	pop	d
	pop	b
	pop	psw
	ret
;
; Test 4 is for multiple fonts.
;
text4:
	lhld	device
	call	vopnwk
	call	backg
	lhld	minchy
	call	vstheight
	lxi	h,0
	shld	x0
	shld	y0

	mvi	b,8
	lxi	d,1000h
	xra	a	;Outer loop (fonts)
t4loop:	sta	tcolor
	call	vstfont
	inr	a
	lxi	h,0
	shld	x0
	push	psw
	mvi	c,8
	xra	a
t4col:	ani	3	;Inner loop (write modes)
	inr	a
	sta	wrmode
	call	vswrmode	
	call	txttest2
	lhld	x0
	dad	d
	shld	x0
	dcr	c
	jnz	t4col
	pop	psw
	lhld	y0
	dad	d
	shld	y0
	dcr	b
	jnz	t4loop
	xra	a
	call	vswrmode
	jmp	tableau
;
; Test 5 is for text rotation. It draws text with rotation at 10 degree
; intervals. Most drivers either won't rotate the text at all, or will
; rotate it only at right angles.
;
text5:
	lhld	device
	call	vopnwk
	call	backg
	call	text5body
	jmp	tableau

text5body:
	lhld	minchy		;Select minimum character height
	call	vstheight	
	xra	a
	call	vswrmode
	lxi	b,36
	lxi	h,sines
text5a:	push	b
	push	h		;HL points at sines table
	mov	e,m
	inx	h
	mov	d,m		;DE = angle
	xchg			;HL = angle
	lxi	d,txtmsg
	call	mdechl		;Write angle to buffer
	xra	a
	stax	d		;Terminating nul
	pop	h

	lxi	d,intin
	lxi	b,6
	call	doldir		;Copy first 3 words, these are the parameters 
	call	vstrotation	;for vst_rotation
	lxi	d,ptsin		;Last 2 words are text coordinates
	lxi	b,4
	call	doldir
	push	h		;HL-> next sines table entry
	lxi	h,txtmsg		;Address of text
	call	vatext		;Write the text
	pop	h
	pop	b
	dcx	b
	mov	a,b
	ora	c
	jnz	text5a
	ret
;
; Text test 6 is intended to draw text at all possible pixel alignments. This
; is inherited from my GEM driver tests; GEM drivers often special-case the
; scenario where text is aligned on a byte boundary.
;
text6:	lhld	device
	call	vopnwk
	call	backg
	lhld	minchy	;Select minimum text size
	call	vstheight
	lhld	csize	;Get character cell width
	call	rrhl
	call	rrhl
	call	rrhl	;Divide by 8; that is the horizontal step
	shld	thstep	

	mvi	a,1
	sta	tcolor

	lxi	h,0
	shld	x0
	shld	y0
	xra	a

t6loop:	push	psw	;And then draw the text, moving across by 
	push	h	;(cell size / 8) and up by cell size with each step
	ani	3
	inr	a
	sta	wrmode
	call	vswrmode
;
; This time, the vertical loop (X position) is the inner loop, and the 
; horizontal loop (write mode) is the outer.
;
t6col:	call	txttest2
	lhld	thstep
	xchg
	lhld	x0
	dad	d
	shld	x0
	lhld	csize+2
	xchg	
	lhld	y0
	dad	d
	shld	y0
	mov	a,h	;Stop when it reaches the top of the screen
	ani	80h
	jz	t6col

	lxi	h,0
	shld	y0
	pop	h
	lxi	d,1000h
	dad	d
	shld	x0
	pop	psw
	inr	a
	cpi	8
	jc	t6loop

	xra	a
	call	vswrmode
	jmp	tableau
;
; Divide HL by 2, preserving AF
;
rrhl:	push	psw
	mov	a,h		;Let HL = HL >> 1
	ana	a
	rar
	mov	h,a
	mov	a,l
	rar
	mov	l,a
	pop	psw
	ret
;
	dseg
tcolor:	db	0		;Current text colour
wrmode:	db	0		;Current write mode

wmds:	db	' Replace'	;Text renderings of write modes
	db	' Trans  '
	db	' XOR    '
	db	' Rev trn'
txtmsg:	ds	40		;Buffer to build a text message in

	extrn	sines		;Precalculated sin/cos values for text test 5
;
; Metrics at various requested sizes
;
wsize0:	dw	0
	dw	0,0	;Size of a letter
csize0:	dw	0,0	;Size of a cell
wsize1:	dw	0
	dw	0,0	;Size of a letter
csize1:	dw	0,0	;Size of a cell
wsize2:	dw	0
	dw	0,0	;Size of a letter
csize2:	dw	0,0	;Size of a cell
wsize3:	dw	0
	dw	0,0	;Size of a letter
csize3:	dw	0,0	;Size of a cell
;
; Results from vst_height
;
wsize:	dw	0,0	;Size of a letter
csize:	dw	0,0	;Size of a cell
	cseg

;
; ==================== Miscellaneous Tests ================================
;
; "Hidden" test pattern. This is here for historical reasons - it was 
; originally the only pattern that GSXTEST could draw.
;
	dseg
;
; Lines to draw
;
ldata1:	dw	4000h, 6000h
	dw	3000h, 3000h
	dw	5000h, 5000h
	dw	3000h, 5000h
	dw	5000h, 3000h
	dw	4000h, 6000h	
;
; Area to fill
;
area1:	dw	0, 0
	dw	7FFFh, 0
	dw	5000h, 2000h
	dw	3000h, 2000h
;
; Rectangle to fill
;
barxy:	dw	0, 7000h	;Opposite corners
	dw	1000h, 7FFFh	;of a rectangle

	cseg


option0:
	lhld	device
	call	vopnwk
	rc
	lxi	h, ldata1	;Draw a test line
	lxi	d, 6
	call	vpline	
	mvi	a, 3		;Select hatches
	call	vsfinterior
	mvi	a, 6		;Choose hatch style
	call	vsfstyle
	lxi	h,area1		;Fill area
	lxi	d, 4
	call	vfillarea
	lxi	h,barxy		;Draw a filled bar
	call	vbar	
tableau:
	call	vupdwk
	lda	device
	cpi	10		;If outputting to screen, pause
	cc	getkey
	call	vclswk
	lhld	curmenu
	pchl
;
backgonly:
	lhld	device
	call	vopnwk
	call	backg1
	jmp	tableau
;
; ==================== Helper Functions ===================================
;
; Copy a point from HL to DE, adding X0 to the X-coord and Y0 to the Y-coord
;
copypt:	push	b	;Loop counter
	mov	c,m
	inx	h
	mov	b,m
	inx	h	;BC = X
	push	h
	lhld	x0
	dad	b	;HL = X-coord
	xchg		;DE = X-coord HL=dest
	mov	m,e
	inx	h
	mov	m,d
	inx	h
	xchg
	pop	h
	
	mov	c,m
	inx	h
	mov	b,m	;BC = Y
	inx	h
	push	h
	lhld	y0
	dad	b	;HL = Y-coord
	xchg		;DE = Y-coord HL=dest
	mov	m,e
	inx	h
	mov	m,d
	inx	h
	xchg		;HL = Y-coord DE=dest
	pop	h

	pop	b
	ret
;		
	dseg
;
; Shapes for the various tests. For the first polyline test, 8 separate lines
;
lp0:	dw	800h, 800h, 700h, 200h
	dw	800h, 800h, 900h, 200h	
	dw	800h, 800h, 200h, 700h
	dw	800h, 800h, 200h, 900h
	dw	800h, 800h, 700h, 0E00h
	dw	800h, 800h, 900h, 0E00h
	dw	800h, 800h, 0E00h, 700h
	dw	800h, 800h, 0E00h, 900h
;
; The star used for the second polyline test
;
star:	dw	800h, 0F00h
	dw	0A00h, 0100h
	dw	0100h, 0C00h
	dw	0F00h, 0C00h
	dw	0600h, 0100h
	dw	800h, 0F00h
;
; The octagon used for fill test 5
;
octagon:
	dw	100h, 400h
	dw	100h, 0C00h
	dw	400h, 0F00h
	dw	0C00h, 0F00h
	dw	0F00h, 0C00h
	dw	0F00h, 400h
	dw	0C00h, 100h
	dw	400h, 100h
	dw	100h, 400h
;
; A diamond of four points, used for polymarker test
;
diamond: dw	800h,400h
	dw	800h,0C00h
	dw	400h,800h
	dw	0C00h,800h
;
; A rectangle, used for bar tests
;
bar0:	dw	100h, 100h
	dw	0F00h, 0F00h
;
; ==================== Draw the background =================================
;
; The four quadrants of the screen, as v_bar rectangles 
;
bgrect1: dw	0,0,     3FFFh, 3FFFh
bgrect2: dw	4000h,0, 7FFFh, 3FFFh
bgrect3: dw	0,4000h, 3FFFh, 7FFFh
bgrect4: dw	4000h,4000h, 7FFFh, 7FFFh

	cseg
;
; This paints the background pattern
;
backg:
	lda	drawbg		;If background is disabled, come straight
	ora	a		;back out
	rz
backg1:	mvi	a,1
	call	vsfinterior	
	lhld	dcolrs		;Is this a colour display?
	mov	a,h
	ora	a
	jnz	bgcolr		;>= 256 colours, so yes
	mov	a,l
	cpi	4		;>= 4 colours, so yes
	jc	bgmono

bgcolr:	xra	a		;Draw the background (colour display)
	call	vsfcolor	;Four rectangles, in colours 0,1,2,3
	lxi	h,bgrect1
	call	rect
	mvi	a,1
	call	vsfcolor
	lxi	h,bgrect2
	call	rect
	mvi	a,2
	call	vsfcolor
	lxi	h,bgrect3
	call	rect
	mvi	a,3
	call	vsfcolor
	lxi	h,bgrect4
	jmp	rect
;
bgmono:	
	xra	a		;Draw the background (mono display)
	call	vsfcolor	;Four rectangles, in colours 0,1,1,0
	lxi	h,bgrect1
	call	rect
	mvi	a,1
	call	vsfcolor
	lxi	h,bgrect2
	call	rect
	lxi	h,bgrect3
	call	rect
	xra	a
	call	vsfcolor
	lxi	h,bgrect4
	jmp	rect
;
; Draw a filled rectangle. This uses the bar GDP, or in the unlikely event 
; that one is not provided, the generic filled polygon
;
rect:	
	lxi	d,ptsin	;Move the parameters to PTSIN
	lxi	b,8
	call	doldir
	lda	gdplist
	dcr	a
	jz	rbar	;We have a bar GDP, use it.
;
; There is no bar GDP, so fake one.
;		   +0 +2   +4 +6   +8 +A   +C +E
; Currently holds (LX,TY) (RX,BY)
; Change to       (LX,TY) (LX,BY) (RX,BY) (RX,TY)
;
	lhld	ptsin+4		;Right X
	shld	ptsin+8
	shld	ptsin+12	
	lhld	ptsin+6		;Bottom Y
	shld	ptsin+10
	lhld	ptsin
	shld	ptsin+4		;Left X
	lhld	ptsin+2
	shld	ptsin+14	
	lxi	h,4
	shld	nptsin
	lxi	h,9		;v_fillarea
	jmp	gsxcall
;
rbar:	lxi	h,2		;Draw using the bar GDP: 2 points
	shld	nptsin
	lxi	h,1		;GDP selector
	shld	contrx
	lxi	h,11		;Do a GDP
	jmp	gsxcall	
;
; Copy BC bytes from HL to DE, leaving HL and DE pointing to the first 
; uncopied bytes and BC=0. 
;
; On a Z80 this will be replaced by an actual LDIR instruction
;
doldir:
	push	psw
ldir1:	mov	a,m
	stax	d
	inx	d
	inx	h
	dcx	b
	mov	a,b
	ora	c
	jnz	ldir1
	pop	psw
	ret
;
; ==================== Get workstation info ================================
;
wsinfo: lhld	device
	push	h
	call	vopnwk		;Open the device
	pop	h
	jc	nogsx
	call	vclswk		;Immediately close it
	call	wsisub		;Display the information retrieved
	call	pause
	jmp	menu
;
exit:	rst	0		;General exit from the program
;
; Messages
;
	dseg
notx80:	db	'This program requires an 8080 or Z80 processor.',cr,lf,'$'
mainmenu:
	db	cr,lf,lf,lf
	db	'     GSX Test Tool v2.0  ',cr,lf
	db	'     ==================  ',cr,lf
	db	'A    Cell Array tests',cr,lf
	db	'B    Draw background? ($'
ena:	db	'En$'
disa:	db	'Dis$'
mainm1:	db	'abled)',cr,lf
	db	'C    Colour tests',cr,lf
;	db	'D    Change device',cr,lf
	db	'E    Escape tests',cr,lf
	db	'F    Fill tests',cr,lf
	db	'G    General Drawing Primitive tests',cr,lf
	db	'I    Input tests',cr,lf
	db	'L    Line tests',cr,lf
	db	'M    Marker tests',cr,lf
	db	'T    Text tests',cr,lf
	db	'W    Workstation info',cr,lf
	db	'X    Test background',cr,lf
	db	'ESC  exit',cr,lf
	db	'     In any menu: ^L for form feed',cr,lf
	db	'$'
;
cellas:	db	cr,lf,lf
	db	'     Cell Array tests',cr,lf
	db	'     ----------------',cr,lf
	db	'1    Draw cell array',cr,lf
	db	'2    Read cell array',cr,lf
	db	'3    Read cell array (palette change)',cr,lf

	db	'M    Main menu',cr,lf
	db	'$'
;
colms:	db	cr,lf,lf
	db	'     Colour tests',cr,lf
	db	'     ------------',cr,lf
	db	'1    Default colours',cr,lf  
	db	'2    DR-Graph colours',cr,lf
	db	'3    IBM 3270 colours',cr,lf
	db	'4    Palette change while drawing',cr,lf  
	db	'5    All colours / truecolour',cr,lf
	db	'M    Main menu',cr,lf
	db	'$'
;
escs:	db	cr,lf,lf
	db	'     Escape tests',cr,lf
	db	'     ------------',cr,lf
	db	'1    Get text screen size',cr,lf  
	db	'2    Text screen output / cursor control',cr,lf
	db	'3    Query mouse',cr,lf
	db	'4    Hard copy',cr,lf
	db	'5    Graphics cursor',cr,lf
	db	'M    Main menu',cr,lf
	db	'$'
;
fills:	db	cr,lf,lf
	db	'     Filled polygon tests',cr,lf
	db	'     --------------------',cr,lf
	db	'1    Fill hollow mode/colour',cr,lf
	db	'2    Fill solid mode/colour',cr,lf
	db	'3    Fill pattern mode/colour',cr,lf
	db	'4    Fill hatch mode/colour',cr,lf
	db	'5    Fill all patterns',cr,lf
	db	'M    Main menu',cr,lf
	db	'$'
;
gdpms:	db	cr,lf,lf
	db	'     General Drawing Primitive tests',cr,lf
	db	'     -------------------------------',cr,lf
	db	'1    Bar mode/colour',cr,lf  
	db	'2    Bar all patterns',cr,lf
	db	'3    Bar all colours',cr,lf
	db	'4    Arc mode/colour',cr,lf
	db	'5    Arc mode/pattern',cr,lf
	db	'6    Arc mode/width',cr,lf
	db	'7    Pie slice mode/colour',cr,lf
	db	'8    Pie slice mode/pattern',cr,lf
	db	'9    Circle mode/colour',cr,lf
	db	'A    Circle mode/pattern',cr,lf
	db	'M    Main menu',cr,lf
	db	'$'
;
inputs:	db	cr,lf,lf
	db	'     Input tests',cr,lf
	db	'     -----------',cr,lf
	db	'1    Locator (request)',cr,lf
	db	'2    Locator (sample)',cr,lf
	db	'3    Valuator (request)',cr,lf
	db	'4    Valuator (sample)',cr,lf
	db	'5    Choice (request)',cr,lf
	db	'6    Choice (sample)',cr,lf
	db	'7    String (request)',cr,lf
	db	'8    String (sample)',cr,lf
	db	'D    Change device number',cr,lf
	db	'M    Main menu',cr,lf
	db	'$'

lines:	db	cr,lf,lf
	db	'     Polyline tests',cr,lf
	db	'     --------------',cr,lf
	db	'1    Polyline mode/colour 1',cr,lf
	db	'2    Polyline mode/colour 2',cr,lf
	db	'3    Polyline mode/style  1',cr,lf
	db	'4    Polyline mode/style  2',cr,lf
	db	'5    Polyline mode/width  1',cr,lf
	db	'6    Polyline mode/width  2',cr,lf
	db	'M    Main menu',cr,lf
	db	'$'

markers:
	db	cr,lf,lf
	db	'     Polymarker tests',cr,lf
	db	'     --------------',cr,lf
	db	'1    Polymarker mode/style',cr,lf
	db	'2    Polymarker mode/colour',cr,lf
	db	'3    Polymarker mode/height',cr,lf
	db	'4    Polymarker style/height',cr,lf
	db	'M    Main menu',cr,lf
	db	'$'

texts:	db	cr,lf,lf
	db	'     Text output tests',cr,lf
	db	'     -----------------',cr,lf
	db	'1    Text info',cr,lf
	db	'2    Text mode/colour',cr,lf
	db	'3    Text mode/size',cr,lf
	db	'4    Text mode/fonts',cr,lf
	db	'5    Text rotation',cr,lf
	db	'6    Text alignment',cr,lf
	db	'M    Main menu',cr,lf
	db	'$'

	cseg	
;
; For parsing the command line -- skip whitespace
;
skipsp:
	mov	a,m
	cpi	9
	jz	skips1
	cpi	' '
	rnz
skips1:	inx	h
	jmp	skipsp
;
; Returns NC if digit, C otherwise
;
isdigit:
	cpi	'0'
	rc
	cpi	'9'+1
	cmc
	ret
;
; Display error if GSX not detected
;
nogsx:	lxi	d,nogsxm
	call	print
	ret
;
	dseg
curmenu: dw	0	;Menu to return to after drawing a test pattern
device:	dw	1	;GSX device number
inpdev:	dw	1	;Number of input device
drawbg:	db	0FFh	;Draw background?
devm:	db	'GSX device:         $'
inpdevm:
	db	'Input device:       $'
nogsxm:	db	'Failed to open device - bad device number or GSX not '
	db	'loaded?',13,10,'$'
;
; Captions for displaying workstation info
;
res:	db	'Device resolution:  $'
cscl:	db	'Continuous scaling: $'
pxls:	db	'Pixel size (um):    $'
chsz:	db	'Character sizes:    $'
linest:	db	'Line styles:        $'
linewid: db	'       widths:  $'
markst:	db	'Marker styles:      $'
markhgt: db	'       heights: $'
fonts:	db	'       fonts:   $'
fillp:	db	'Fill patterns:      $'
fillh: db	'       hatches: $'
iscol:	db	'Colour supported:   $'
isrot:	db	'Text rotation:      $'
isfill:	db	'Filled areas:       $'
iscell:	db	'Read cell array:    $'
colrs:	db	'Usable colours:     $'
gdps:	db	'Supported GDPs:     $'
nloc:	db	'Locators:           $'
nval:	db	'Valuators:          $'
nchc:	db	'Choice devices:     $'
wstype:	db	'Workstation type:   $'
xxx:	db	' x $'
yes:	db	'Yes$'
no:	db	'No $'
of:	db	' of $'
csp:	db	': $'

;
; Used to render the list of GDPs as text
;
gdptypes:
	db	'[BAR]   [ARC]   [PIE]   [CIRCLE][RULER ][------]'
;
; Used to render the GDP attributes as text
;
gdpattr:
	db	'[LINE]  [MARKER][TEXT]  [FILL]  [NONE]  [------]'
;
; Used to render the list of workstation types as text
;
wstypes:
	db	'OUTPUT  INPUT   IN/OUT  STORAGE METAFILE????????'

crlf:	db	cr,lf,'$'

keym:	db	   '[Press SPACE]$'
keyc:	db	cr,'             ',cr,'$'
	cseg
;
; Display a 'Press SPACE' prompt, wait for a keypress, then remove the prompt.
;
pause:	lxi	d,keym
	call	print
	call	getkey
	lxi	d,keyc
	jmp	print
;
; Get a key and convert lower case to upper
;
getkeyu:
	call	getkey
	cpi	'a'
	rc
	cpi	'z'+1
	rnc
	ana	a
	sbi	20h	;Enforce upper case
	ret
;
; Get a key without echoing it. Under CP/M 3 this is done with E=0FDh. Under
; CP/M 2 this has to be done by busy-waiting.
;
getkey: mvi	c,SBDOSVER
	call	FDOS
	cpi	30h
	jc	gkey1
	mvi	c,CDIRECT	;CP/M 3: Wait for input
	mvi	e,0FDh
	call	FDOS
	jmp	gkey2

gkey1:	mvi	c,CDIRECT	;CP/M 2: Poll input until there is a character
	mvi	e,0FFh
	call	FDOS
	ora	a
	jz	gkey1

gkey2:	cpi	12		;If it was ^L, then send form feed to the 
	rnz			;printer.
	mvi	c,LWRITE
	mov	e,a
	call	FDOS
	jmp	getkey
;
; Display workstation information:
;
wsisub:	lxi	d,devm		;Device ID
	call	print
	lhld	device
	call	dechl
	call	prcrlf

	lxi	d,res		;Resolution
	call	print
	lhld	scrw
	inx	h
	call	dechl
	lxi	d,xxx
	call	print
	lhld	scrh
	inx	h
	call	dechl
	call	prcrlf

	lxi	d,cscl		;Continuous scaling
	call	print
	lhld	scaling
	call	prbool
	call	prcrlf

	lxi	d,pxls		;Pixel size
	call	print
	lhld	pixelw
	call	dechl
	lxi	d,xxx
	call	print
	lhld	pixelh
	call	dechl
	call	prcrlf

	lxi	d,chsz		;Character sizes
	call	print
	lhld	chsizes
	call	dechl
	lxi	d,fonts		;and number of fonts
	call	print
	lhld	nfonts
	call	dechl
	call	prcrlf

	lxi	d,linest	;Line styles / sizes
	call	print
	lhld	lstyles
	call	dechl
	lxi	d,linewid
	call	print
	lhld	lwidths
	call	dechl
	call	prcrlf

	lxi	d,markst	;Marker styles / sizes
	call	print
	lhld	mstyles
	call	dechl
	lxi	d,markhgt
	call	print
	lhld	msizes
	call	dechl
	call	prcrlf

	lxi	d,fillp	;Fill patterns / hatches
	call	print
	lhld	patrns
	call	dechl
	lxi	d,fillh
	call	print
	lhld	hatches
	call	dechl
	call	prcrlf

	lxi	d,iscol	;Colour support
	call	print
	lhld	mcolr
	call	prbool
	call	prcrlf

	lxi	d,colrs ;Simultaneous colours
	call	print
	lhld	dcolrs
	call	dechl
	lxi	d,of
	call	print
	lhld	pcolrs
	call	dechl
	call	prcrlf

	lxi	d,gdps ;Supported GDPs
	call	print
	lhld	gdpmax
	call	dechl
	call	prcrlf

	mvi	b,10	;GDP info
	lxi	d,0
showg:	push	b
	push	d
	lxi	h,gdplist
	dad	d
	mov	e,m
	inx	h
	mov	d,m	;DE = GDP type
	xchg		;HL = GDP type
	dcx	h
	lxi	b,gdptypes
	call	lookup

	pop	d
	pop	b
	inx	d
	inx	d
	dcr	b
	jnz	showg
	call	prcrlf
	mvi	b,10
	lxi	d,0
showg2:	push	b
	push	d
	lxi	h,gdpatts
	dad	d
	mov	e,m
	inx	h
	mov	d,m	;DE = GDP attribute
	xchg		;HL = GDP attribute
	lxi	b,gdpattr
	call	lookup

	pop	d
	pop	b
	inx	d
	inx	d
	dcr	b
	jnz	showg2
	call	prcrlf

	lxi	d,isrot		;Can rotate text
	call	print
	lhld	rtext
	call	prbool
	call	prcrlf
	lxi	d,isfill	;Can fill areas
	call	print
	lhld	canfill
	call	prbool
	call	prcrlf
	lxi	d,iscell	;Can read cell array
	call	print
	lhld	rdcell
	call	prbool
	call	prcrlf

	lxi	d,nloc		;Count of locators
	call	print
	lhld	nlocs
	call	dechl
	call	prcrlf	

	lxi	d,nval		;Count of valuators
	call	print
	lhld	nvals
	call	dechl
	call	prcrlf	

	lxi	d,nchc		;Count of choice devices
	call	print
	lhld	nchcs
	call	dechl
	call	prcrlf	

	lxi	d,wstype	;Workstation type
	call	print
	lhld	wstyp
	call	dechl
	lxi	d,csp
	call	print

	lhld	wstyp
	lxi	b,wstypes
	call	lookup
	call	prcrlf
;
; Max / min sizes. This just dumps PTSOUT rather than printing 
; individual captions.
;
	mvi	b,12
	lxi	h,wspout
showws:
	mov	e,m
	inx	h
	mov	d,m
	inx	h
	push	b
	push	d
	push	h
	call	hexde
	mvi	c,CWRITE
	mvi	e,' '
	call	FDOS
	pop	h
	pop	d
	pop	b
	dcr	b
	jnz	showws
	call	prcrlf	
	ret
;
; Expand the value 0-5 to an 8-character string. HL=value BC->table of strings.
;
lookup:
	mov	a,h
	ora	a
	jnz	lookup1
	mov	a,l	;If it is >= 5, cap it at 5
	cpi	5
	jc	lookup2
lookup1:
	lxi	h,5
lookup2:
	dad	h	;*2
	dad	h	;*4
	dad	h	;*8
	dad	b	;
	mvi	b,8
lookup3:
	push	b	;Write 8 characters
	push	h
	mov	e,m
	mvi	c,CWRITE
	call	FDOS
	pop	h
	pop	b
	inx	h
	dcr	b
	jnz	lookup3
	ret
;
prcrlf:	lxi	d,crlf	;Print CR/LF
	jmp	print

prbool:	lxi	d,yes	;Print Yes/No value
	mov	a,h
	ora	l
	jnz	print
	lxi	d,no
print:	mvi	c,CWSTR
	jmp	FDOS
;
dechl:	mvi	b,0	;Print decimal number. B is set to nonzero at first
	lxi	d,10000	;nonzero digit found
	call	decdgt
	lxi	d,1000
	call	decdgt
	lxi	d,100
	call	decdgt
	lxi	d,10
	call	decdgt
	mov	a,l
	adi	'0'
	mov	e,a
	mvi	c,CWRITE
	jmp	fdos
;
; Divide HL by DE. Quotient in C, remainder in HL. B=0 if only zeroes output,
; else B is nonzero 
;
decdgt:	mvi	c,'0'
ddgt1:	mov	a,l	;Subtract DE from HL
	sub	e
	mov	l,a
	mov	a,h
	sbb	d
	mov	h,a	
	jc	ddgt2	;If that overflowed division is complete
	inr	c
	jmp	ddgt1
;
ddgt2:	dad	d	;Add on the last DE which caused the overflow
	push	h
	mov	a,c
	cpi	'0'	;Is it a zero?
	jnz	ddgt3
	mov	a,b
	ora	a	;Have we encountered non-zero digits?
	jnz	ddgt3
	pop	h	;No, this must be a leading zero
	ret
;
ddgt3:	push	b
	mov	e,c
	mvi	c,CWRITE
	call	FDOS
	pop	b
	mvi	b,1	;We have output at least one digit
	pop	h
	ret
;
	dseg
mdecwr:	dw	0
	cseg
;
; As DECHL, but writes the value in HL to memory at DE.
;
mdechl:	xchg
	shld	mdecwr	;Destination address
	xchg
	mvi	b,0
	lxi	d,10000
	call	mdecdgt
	lxi	d,1000
	call	mdecdgt
	lxi	d,100
	call	mdecdgt
	lxi	d,10
	call	mdecdgt
	mov	a,l
	adi	'0'
	lhld	mdecwr
	mov	m,a
	inx	h
	mvi	m,0
	xchg
	ret
;
; Divide HL by DE. Quotient in C, remainder in HL
;
mdecdgt:
	mvi	c,'0'
mddgt1:	mov	a,l	;Subtract DE from HL
	sub	e
	mov	l,a
	mov	a,h
	sbb	d
	mov	h,a	
	jc	mddgt2	;If that overflowed division is complete
	inr	c
	jmp	mddgt1
;
mddgt2:	dad	d	;Add on the last DE which caused the overflow
	push	h
	mov	a,c
	cpi	'0'	;Is it a zero?
	jnz	mddgt3
	mov	a,b
	ora	a	;Have we encountered non-zero digits?
	jnz	mddgt3
	pop	h	;No, this must be a leading zero
	ret
;
mddgt3:	lhld	mdecwr
	mov	m,c	;Append digit to the buffer
	inx	h
	shld	mdecwr
	mvi	b,1	;We have output at least one digit
	pop	h
	ret
;
; Output a space, preserving all registers
;
dspace:
	push	h
	push	d
	push	b
	push	psw
	mvi	c,CWRITE
	mvi	e,' '
	call	FDOS
	pop	psw
	pop	b
	pop	d
	pop	h
	ret
;
; Output CR/LF, preserving all registers
;
dcrlf:	push	h
	push	d
	push	b
	push	psw
	mvi	c,CWRITE
	mvi	e,cr
	call	FDOS
	mvi	c,CWRITE
	mvi	e,lf
	call	FDOS
	pop	psw
	pop	b
	pop	d
	pop	h
	ret
;
; Debug code to output registers as hex
;
;dhexbc:	push	d
;	mov	d,b
;	mov	e,c
;	call	dhexde
;	pop	d
;	ret
;
;dhexhl:
;	xchg
;	call	dhexde
;	xchg
;	ret
;
;dhexde: push	h
;	push	d
;	push	b
;	push	psw
;	call	hexde
;	pop	psw
;	pop	b
;	pop	d
;	pop	h
;	ret
;
; Output the value in DE as hex
;
hexde:	mov	a,d
	push	d	;High byte
	call	hexa
	pop	d
	mov	a,e	;Low byte
hexa:	push	psw
	rar
	rar
	rar
	rar
	call	hexn	;High nibble
	pop	psw	;Low nibble
hexn:	ani	0Fh
	cpi	0Ah
	jc	hexn1
	adi	7
hexn1:	adi	'0'
	mov	e,a
	mvi	c,CWRITE
	jmp	FDOS
;
; ==================== GSX operations =====================================
;
; Open GSX workstation
;	
vopnwk:
	shld	wsiin
	lxi	h,wsiin		;Point the INTIN / INTOUT / PTSOUT
	shld	pintin		;arrays at the ones specific to this
	lxi	h,wsiout	;function
	shld	pintot
	lxi	h,wspout
	shld	pptsot
	lxi	h,10		;Set parameter counts
	shld	nintin
	lxi	h,0
	shld	nptsin
	inx	h		;OPEN WORKSTATION
	call	gsxcall
	lxi	h,ptsout
	shld	pptsot
	lxi	h,intout
	shld	pintot
	lxi	h,intin
	shld	pintin
	lda	nintot		
	cpi	45		;Should return NC if worked, C if failed
	ret
;
; A lot of these are reasonably simple wrappers that don't take parameters
; or return results
;
vclswk:	
	lxi	h,2		;Close workstation
	jmp	gsxcall0
;
vclrwk:
	lxi	h,3		;Clear workstation
	jmp	gsxcall0
;
vupdwk:
	lxi	h,4		;Update workstation
	jmp	gsxcall0
;
curup:	lxi	h,4		;Text cursor up
	jmp	vescape
;
curdown:
	lxi	h,5		;Text cursor down
	jmp	vescape
;
curright:
	lxi	h,6		;Text cursor right
	jmp	vescape
;
curleft:
	lxi	h,7		;Text cursor left
	jmp	vescape
;
thome:	lxi	h,8		;Text cursor home
	jmp	vescape
;
tcleos:	lxi	h,9		;Clear to end of screen
	jmp	vescape
;
tcleol:	lxi	h,10		;Clear to end of line
	jmp	vescape
;
vescape:
	shld	contrx		;GSX general escape, HL=escape function
	lxi	h,5		;And call GSX escape function
;
; General wrapper for GSX call with no parameters or results
;
gsxcall0:
	xchg
	lxi	h,0
	shld	nintin
	shld	nptsin
	xchg
;
; General wrapper for GSX call. Enter with HL = function
;
gsxcall:
	shld	contrl	
	lxi	h,0
	shld	nptsot
	shld	nintot
;
; For debugging, hold the GSX function and subfunction in registers so I 
; can see them at a glance if I put a breakpoint on the GSX call.
;
	lda	contrl	;For tracing: A = GSX function
	lhld	contrx	;For tracing: HL= subfunction
	lxi	d,gsxpb
	mvi	c,GSXFUNC
	jmp	FDOS
;
; Set text cursor position: D=row E=column
;
setcurpos:
	push	d
	mov	l,d
	mvi	h,0
	inx	h	;GSX uses 1-based coordinates
	shld	intin
	mov	l,e
	mvi	h,0
	inx	h
	shld	intin+2
	lxi	h,0	;No incoming points
	shld	nptsin
	lxi	h,2	;2 incoming integers
	shld	nintin
	lxi	h,11	;Set cursor position
	shld	contrx
	lxi	h,5
	call	gsxcall
	pop	d
	ret
;
; Draw polyline; HL->coords, DE=count
;
vpline:
	shld	pptsin	;Point PTSIN at polyline to draw
	xchg
	shld	nptsin	;And set count
	lxi	h,0
	shld	nintin
	lxi	h,6	
	call	gsxcall
	lxi	h,ptsin	;Restore original ptsin
	shld	pptsin
	ret
;
; Print a 0-terminated ASCII string at HL. Coordinates in PTSIN.
;
vatext:
	push	psw
	push	b
	push	d
	push	h
	xchg		;DE->string
	lxi	h,intin
	lxi	b,0
vatxt1:	ldax	d
	inx	d
	ora	a
	jz	vatxt2
	mov	m,a	;Otherwise expand character to a word and append it
	inx	h	;to intin
	mvi	m,0
	inx	h
	inx	b
	jmp	vatxt1
;
vatxt2:	mov	l,c
	mov	h,b		;HL = length
	shld	nintin
	lxi	h,1
	shld	nptsin
	lxi	h,8
	call	gsxcall
	pop	h
	pop	d
	pop	b
	pop	psw
	ret
;
vgtext:
	shld	pintin	;Point INTIN at text to output
	xchg
	shld	nintin	;And set length
	lxi	h,1
	shld	nptsin	;Set PTSIN count (coordinates to be set by caller)
	lxi	h,8
	call	gsxcall
	lxi	h,intin	;Restore original intin
	shld	pintin
	ret
;
vfillarea:
	shld	pptsin	;Point PTSIN at shape to draw
	xchg
	shld	nptsin	;And set count
	lxi	h,0
	shld	nintin
	lxi	h,9
	call	gsxcall
	lxi	h,ptsin	;Restore original ptsin
	shld	pptsin
	ret
;
vqcolor:
	push	h	;Query colour representation; HL=ink DE=req/act
	shld	intin
	xchg
	shld	intin+2
	xchg
	lxi	h,2
	shld	nintin
	lxi	h,0
	shld	nptsin
	lxi	h,26
	call	gsxcall
	lhld	nintot
	mov	a,h
	ora	l	;Returns Z if no result, NZ if result
	pop	h
	ret
;
vscolor:
	push	h	;Set palette entry. DE=colour HL->RGB values
	push	d
	push	b
	xchg
	shld	intin
	xchg
	lxi	d,intin+2
	lxi	b,6
	call	doldir
	lxi	h,4
	shld	nintin
	lxi	h,0
	shld	nptsin
	lxi	h,14
	call	gsxcall
	pop	b
	pop	d
	pop	h
	ret
;
vbar:	shld	pptsin	;Point PTSIN at shape to draw
	lxi	h,2
	shld	nptsin	;And set count
	lxi	h,1
	shld	contrx	;Select BAR primitive
	lxi	h,0
	shld	nintin
	lxi	h,11	;GDP
	call	gsxcall
	lxi	h,ptsin	;Restore original ptsin
	shld	pptsin
	ret
;
; Reverse video on
;
revon:	push	psw
	push	b
	push	d
	push	h
	lxi	h,13
	jmp	revc
;
; Reverse video off
;
revoff:	push	psw
	push	b
	push	d
	push	h
	lxi	h,14
revc:	call	vescape
	pop	h
	pop	d
	pop	b
	pop	psw
	ret	
;
; Output text to text screen. Enter with DE->0-terminated ASCII string
;
esctext:
	lxi	h,intin
	lxi	b,0
esct0:	ldax	d
	mov	m,a
	inx	h
	mvi	m,0
	inx	h
	ora	a
	jz	esct1
	inx	d
	inx	b
	jmp	esct0
;
esct1:	mov	h,b
	mov	l,c	;BC = count of letters
	shld	nintin
	lxi	h,0
	shld	nptsin
	lxi	h,12
	shld	contrx
	lxi	h,5
	jmp	gsxcall
;
; Draw the graphics cursor at (HL,DE)
;
vshowc: shld	ptsin
	xchg
	shld	ptsin+2
	lxi	h,18
	shld	contrx
	lxi	h,0
	shld	nintin
	inx	h
	shld	nptsin
	lxi	h,5
	jmp	gsxcall
;
; Set GSX write mode to A, preserving all registers
;
vswrmode:	
	push	psw
	push	b
	push	d
	push	h
	mov	l,a	;Store the parameter in the second word of INTIN as 
	mov	h,0	;well as the first (workaround for buggy BBC Micro 
	shld	intin+2	;screen drivers DDBBC0 / DDBBC1)
	lxi	d,32	;Function
;
; Generic 1-parameter GSX call. DE=function A=parameter.
;
gsxcall1:
	mov	l,a
	mvi	h,0
	shld	intin
	lxi	h,0
	shld	nptsin
	lxi	h,1
	shld	nintin
	xchg
	call	gsxcall
	pop	h
	pop	d
	pop	b
	pop	psw
	ret
;
;
; Set GSX line style to A, preserving all registers
;
vslstyle:
	push	psw
	push	b
	push	d
	push	h
	lxi	d,15
	jmp	gsxcall1
;
; Set GSX line colour to A, preserving all registers
;
vslcolor:
	push	psw
	push	b
	push	d
	push	h
	lxi	d,17
	jmp	gsxcall1
;
; Same for marker type
;
vsmtype:
	push	psw
	push	b
	push	d
	push	h
	lxi	d,18
	jmp	gsxcall1

;
; Same for marker colour
;
vsmcolor:
	push	psw
	push	b
	push	d
	push	h
	lxi	d,20
	jmp	gsxcall1
;
; Same for text font
;
vstfont:
	push	psw
	push	b
	push	d
	push	h
	lxi	d,21
	jmp	gsxcall1
;
; Same for text colour 
;
vstcolor:
	push	psw
	push	b
	push	d
	push	h
	lxi	d,22
	jmp	gsxcall1
;
; Same for fill interior
;
vsfinterior:
	push	psw
	push	b
	push	d
	push	h
	lxi	d,23
	jmp	gsxcall1
;
; Same for fill style
;
vsfstyle:
	push	psw
	push	b
	push	d
	push	h
	lxi	d,24
	jmp	gsxcall1
;
; Same for fill colour
;
vsfcolor:
	push	psw
	push	b
	push	d
	push	h
	lxi	d,25
	jmp	gsxcall1
;
; Set line width to HL, preserving all registers
;
vslwidth:
	push	psw
	push	b
	push	d
	push	h
	lxi	d,16
	shld	ptsin	;Store width in ptsin
	lxi	h,0
	shld	ptsin+2
	shld	nintin
	inx	h
	shld	nptsin
	xchg
	call	gsxcall
	pop	h
	pop	d
	pop	b
	pop	psw
	ret
;
; Set marker height to HL, preserving all registers
;
vsmheight:
	push	psw
	push	b
	push	d
	push	h
	lxi	d,19
	shld	ptsin+2	;Store height in ptsin
	lxi	h,0
	shld	ptsin
	shld	nintin
	inx	h
	shld	nptsin
	xchg
	call	gsxcall
	pop	h
	pop	d
	pop	b
	pop	psw
	ret
;
; Set text angle (parameters already in intin), preserving all registers
;
vstrotation:
	push	psw
	push	b
	push	d
	push	h
	lxi	d,13
	lxi	h,0
	shld	nptsin
	lxi	h,3
	shld	nintin
	xchg
	call	gsxcall
	pop	h
	pop	d
	pop	b
	pop	psw
	ret
;
; Set text height (HL = height), preserving all registers
;
vstheight:
	push	psw
	push	b
	push	d
	push	h
	lxi	d,12
	shld	ptsin+2	;Store height in ptsin
	lxi	h,0
	shld	ptsin	;Set width to 0
	shld	nintin
	inx	h
	shld	nptsin	;1 point passed
	xchg
	call	gsxcall
;
; Get the returned metrics
;
	lxi	h,ptsout
	lxi	d,wsize
	lxi	b,8
	call	doldir
	pop	h
	pop	d
	pop	b
	pop	psw
	ret
;
; Set device input mode
; HL = device type (1=locator 2=valuator 3=choice 4=string)
; DE = mode (1=request 2=sample)
;
vsinmode:
	push	psw
	push	b
	push	d
	push	h
	shld	intin
	xchg
	shld	intin+2
	lxi	h,2
	shld	nintin	
	lxi	h,0
	shld	nptsin
	lxi	h,33
	call	gsxcall
	pop	h
	pop	d
	pop	b
	pop	psw
	ret
;
; ==================== GSX function parameters / results ==================
;
	dseg
gsxpb:	dw	contrl
pintin:	dw	intin
pptsin:	dw	ptsin
pintot:	dw	intout
pptsot:	dw	ptsout

contrl:	dw	0	;Function
nptsin:	dw	0	;#ptsin
nptsot:	dw	0	;#ptsout
nintin:	dw	0	;#intin
nintot:	dw	0	;#intout
contrx:	dw	0	;special
	dw	0,0,0	;Used for output colour index array

wsiin:	dw	0	;Device ID
	dw	1	;Initial line style
	dw	7	;Initial line colour
	dw	1	;Initial marker style
	dw	7	;Initial marker colour
	dw	1	;Initial text style
	dw	7	;Initial text colour
	dw	1	;Initial fill style
	dw	1	;Initial fill index
	dw	7	;Initial fill colour
	dw	1	;Not used in GSX, but scaling mode in GEM

wsiout:
scrw:	dw	0	;Screen width
scrh:	dw	0	;Screen height
scaling:dw	0	;Capable of continuous scaling?
pixelw:	dw	0	;Pixel width, um
pixelh:	dw	0	;Pixel height, um
chsizes: dw	0	;Character sizes
lstyles: dw	0	;Line styles
lwidths: dw	0	;Line widths
mstyles: dw	0	;Marker styles
msizes:	dw	0	;Marker sizes
nfonts:	dw	0	;Fonts
patrns: dw	0	;Patterns
hatches: dw	0	;Hatches
dcolrs:	dw	0	;Colours displayable at once
gdpmax:	dw	0	;Count od GDPs
gdplist: ds	20	;GDP numbers
gdpatts: ds	20	;GDP types
mcolr:	dw	0	;B/W or colour?
rtext:	dw	0	;Can rotate text?
canfill: dw	0	;Can fill areas?
rdcell:	dw	0	;Can read cell array?
pcolrs:	dw	0	;Colours in palette
nlocs:	dw	0	;Number of locators
nvals:	dw	0	;Number of valuators
nchcs:	dw	0	;Number of choice devices
wstyp:	dw	0	;Workstation type
	ds	wsiout + 90 - $

wspout:	dw	0	;Min char width
minchy:	dw	0	;Min char height
maxchx:	dw	0	;Max char width
maxchy:	dw	0	;Max char height
minlw:	dw	0,0	;Min line width
maxlw:	dw	0,0	;Max line width
	dw	0
minmh:	dw	0
	dw	0
maxmh:	dw	0

ptsin:	ds	512
ptsout:	ds	24
intin:	ds	256
intout:	ds	512

	end
