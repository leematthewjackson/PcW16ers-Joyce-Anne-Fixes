;
; Precomputed table of sin / cos values for text direction at 10 degree
; intervals. Each row gives:
;	> Angle (tenths of a degree)
;	> 100 * cos(angle)
;	> 100 * sin(angle)
;	> Coordinates of a point at that angle, on a circle at (16384,16384)
;	 radius 12288
;
	DSEG

	PUBLIC	SINES

SINES:
	DW	0,100,0,07000h,04000h
	DW	100,98,17,06f45h,04855h
	DW	200,93,34,06d1ah,0506ah
	DW	300,86,50,06991h,05800h
	DW	400,76,64,064c5h,05edah
	DW	500,64,76,05edah,064c5h
	DW	600,49,86,057ffh,06991h
	DW	700,34,93,0506ah,06d1ah
	DW	800,17,98,04855h,06f45h
	DW	900,0,100,04000h,07000h
	DW	1000,-17,98,037abh,06f45h
	DW	1100,-34,93,02f96h,06d1ah
	DW	1200,-50,86,02800h,06991h
	DW	1300,-64,76,02126h,064c5h
	DW	1400,-76,64,01b3bh,05edah
	DW	1500,-86,49,0166fh,057ffh
	DW	1600,-93,34,012e6h,0506ah
	DW	1700,-98,17,010bbh,04855h
	DW	1800,-100,0,01000h,04000h
	DW	1900,-98,-17,010bbh,037abh
	DW	2000,-93,-34,012e6h,02f96h
	DW	2100,-86,-50,0166fh,02800h
	DW	2200,-76,-64,01b3bh,02126h
	DW	2300,-64,-76,02126h,01b3bh
	DW	2400,-49,-86,02801h,0166fh
	DW	2500,-34,-93,02f96h,012e6h
	DW	2600,-17,-98,037abh,010bbh
	DW	2700,0,-100,04000h,01000h
	DW	2800,17,-98,04855h,010bbh
	DW	2900,34,-93,0506ah,012e6h
	DW	3000,50,-86,05800h,0166fh
	DW	3100,64,-76,05edah,01b3bh
	DW	3200,76,-64,064c5h,02126h
	DW	3300,86,-49,06991h,02801h
	DW	3400,93,-34,06d1ah,02f96h
	DW	3500,98,-17,06f45h,037abh
