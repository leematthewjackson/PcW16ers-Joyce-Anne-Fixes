
#include <stdio.h>
#include <math.h>

#define PI 3.141592654

int main(int argc, char **argv)
{
	int c, s, n;

	printf(
";\n"
"; Precomputed table of sin / cos values for text direction at 10 degree\n" 
"; intervals. Each row gives:\n"
";	> Angle (tenths of a degree)\n"
";	> 100 * cos(angle)\n"
";	> 100 * sin(angle)\n"
";	> Coordinates of a point at that angle, on a circle at (16384,16384)\n"
";	 radius 12288\n"
";\n");

	printf("\tDSEG\n\n");
	printf("\tPUBLIC\tSINES\n\n");
	printf("SINES:\n");

	for (n = 0; n < 360; n += 10)
	{
		c = 100 * cos(n * PI / 180.0);
		s = 100 * sin(n * PI / 180.0);
		printf("\tDW\t%d,%d,%d,0%04xh,0%04xh\n",
			n * 10,
			c, s, 
			0x4000 + (int)(0x3000 * cos(n * PI / 180.0)),
			0x4000 + (int)(0x3000 * sin(n * PI / 180.0)));	
	}	
	return 0;
}
